// ═══════════════════════════════════════════════════════════════════════════
// DeepSeek MCP Lite — Background Service Worker
// ═══════════════════════════════════════════════════════════════════════════
// Responsibilities:
//   1. MCP Client (JSON-RPC 2.0 over HTTP / Streamable SSE / Localhost)
//   2. Anti-ban rate limiter with human-like Jitter
//   3. Diagnostics & detailed log store
//   4. Full session backup, compaction & auto-rollover
//   5. Chrome runtime message broker
// ═══════════════════════════════════════════════════════════════════════════

import {
  formatSessionToMarkdown,
  formatSessionToJson,
  compactSessionHistory,
  estimateTokenCount,
  extractMessages,
} from './session-packer.js';
import { generateCurlCommand } from './curl-utils.js';

const DEFAULT_CONFIG = {
  enabled: true,
  servers: [],          // [{id, name, url, enabled, headers:{}, secrets:{}}]
  cachedTools: [],      // [{name, description, inputSchema, serverId}]
  rateLimit: {
    delayBetweenCallsMs: 2000,   // Base delay between consecutive tool executions
    maxConcurrent: 1,            // Strictly sequential
    maxCallsPerMinute: 10,       // Hard ceiling per minute
    timeoutMs: 30000,            // Per-call timeout
    maxResultBytes: 65536,       // Truncate output above 64KB
    requireConfirmation: false,  // Manual user approval per turn
    maxConsecutiveTurns: 5,      // Circuit breaker: max consecutive loops
    preferDomInput: false,       // Keep chat input clean; render results as inline cards in chat body
  },
  rollover: {
    enabled: false,              // Optional: auto-backup and rollover
    tokenThreshold: 45000,       // Trigger when approaching 45k tokens
    format: 'markdown',          // 'markdown' | 'json'
    autoDownload: true,          // Download full backup file to disk
    autoNavigate: true,          // Seamlessly open new session with compacted context
  },
};

let config = { ...DEFAULT_CONFIG };
let callTimestamps = [];
const diagnosticsLog = [];

function addDiagnostic(level, message, detail = null, httpTrace = null) {
  const entry = {
    id: crypto.randomUUID(),
    time: Date.now(),
    level, // 'info' | 'success' | 'warn' | 'error'
    message,
    detail,
    httpTrace,
  };
  diagnosticsLog.push(entry);
  if (diagnosticsLog.length > 100) diagnosticsLog.shift();

  broadcastToDeepSeekTabs({ type: 'DIAGNOSTIC_ENTRY', entry });
}

// ── Startup & Storage ────────────────────────────────────────────────────
// Configure extension icon to open Side Panel directly on click
if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

chrome.action?.onClicked?.addListener(async (tab) => {
  try {
    if (chrome.sidePanel?.open && tab?.windowId) {
      await chrome.sidePanel.open({ windowId: tab.windowId });
      return;
    }
  } catch (err) {
    console.warn('[MCP] sidePanel.open failed:', err);
  }
  await chrome.windows.create({
    url: chrome.runtime.getURL('src/popup.html?mode=window'),
    type: 'popup',
    width: 540,
    height: 780,
  });
});

chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
  chrome.storage.local.get('dsmcp_config', (data) => {
    if (data.dsmcp_config) {
      config = {
        ...DEFAULT_CONFIG,
        ...data.dsmcp_config,
        rateLimit: { ...DEFAULT_CONFIG.rateLimit, ...data.dsmcp_config.rateLimit },
        rollover: { ...DEFAULT_CONFIG.rollover, ...(data.dsmcp_config.rollover || {}) },
      };
    }
    saveConfig();
    addDiagnostic('info', 'DeepSeek MCP Lite v0.4.24 активен');
  });
});

chrome.storage.local.get('dsmcp_config', (data) => {
  if (data.dsmcp_config) {
    config = {
      ...DEFAULT_CONFIG,
      ...data.dsmcp_config,
      rateLimit: { ...DEFAULT_CONFIG.rateLimit, ...data.dsmcp_config.rateLimit },
      rollover: { ...DEFAULT_CONFIG.rollover, ...(data.dsmcp_config.rollover || {}) },
    };
  }
});

function saveConfig() {
  chrome.storage.local.set({ dsmcp_config: config });
}

// ── Global Interception State for Objective Control ──────────────────────
let lastInterceptionAudit = null;
let totalInterceptionsCount = 0;

// ── Message Router ───────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {

    case 'SAVE_LAST_INTERCEPTION':
      lastInterceptionAudit = msg.audit;
      totalInterceptionsCount = msg.totalCount || (totalInterceptionsCount + 1);
      chrome.storage.local.set({
        dsmcp_last_interception: msg.audit,
        dsmcp_total_interceptions: totalInterceptionsCount,
      });
      // Broadcast to any open popup/sidePanel tabs
      chrome.runtime.sendMessage({
        type: 'INTERCEPTION_AUDIT_BROADCAST',
        audit: msg.audit,
        totalCount: totalInterceptionsCount,
      }).catch(() => {});
      sendResponse({ ok: true });
      return false;

    case 'GET_LAST_INTERCEPTION':
      chrome.storage.local.get(['dsmcp_last_interception', 'dsmcp_total_interceptions'], (data) => {
        sendResponse({
          audit: data.dsmcp_last_interception || lastInterceptionAudit || null,
          totalCount: data.dsmcp_total_interceptions || totalInterceptionsCount || 0,
        });
      });
      return true;

    case 'RUN_CHAT_VERIFICATION': {
      (async () => {
        const tabs = await chrome.tabs.query({ url: 'https://chat.deepseek.com/*' });
        if (!tabs || tabs.length === 0) {
          await chrome.tabs.create({ url: 'https://chat.deepseek.com' });
          sendResponse({ ok: false, error: 'Вкладка chat.deepseek.com не была открыта. Мы открыли её в новой вкладке — повторите нажатие через пару секунд.' });
        } else {
          const targetTab = tabs.find(t => t.active) || tabs[0];
          await chrome.tabs.update(targetTab.id, { active: true });
          chrome.tabs.sendMessage(targetTab.id, {
            type: 'TRIGGER_CHAT_VERIFICATION',
            prompt: msg.prompt,
          }).catch(() => {});
          sendResponse({ ok: true, tabId: targetTab.id });
        }
      })();
      return true;
    }

    case 'RUN_CHAT_SUBMIT_TEST': {
      (async () => {
        const tabs = await chrome.tabs.query({ url: 'https://chat.deepseek.com/*' });
        if (!tabs || tabs.length === 0) {
          await chrome.tabs.create({ url: 'https://chat.deepseek.com' });
          sendResponse({ ok: false, error: 'Вкладка chat.deepseek.com не была открыта.' });
        } else {
          const targetTab = tabs.find(t => t.active) || tabs[0];
          await chrome.tabs.update(targetTab.id, { active: true });
          chrome.tabs.sendMessage(targetTab.id, {
            type: 'TRIGGER_CHAT_SUBMIT_TEST',
            prompt: msg.prompt,
          }).catch(() => {});
          sendResponse({ ok: true, tabId: targetTab.id });
        }
      })();
      return true;
    }

    case 'VERIFICATION_STATUS_BROADCAST':
      chrome.runtime.sendMessage(msg).catch(() => {});
      sendResponse({ ok: true });
      return false;

    case 'GET_CONFIG':
      sendResponse(config);
      return false;

    case 'GET_DIAGNOSTICS':
      sendResponse({ logs: diagnosticsLog });
      return false;

    case 'CLEAR_DIAGNOSTICS':
      diagnosticsLog.length = 0;
      sendResponse({ ok: true });
      return false;

    case 'SAVE_CONFIG':
      config = {
        ...DEFAULT_CONFIG,
        ...msg.config,
        rateLimit: { ...DEFAULT_CONFIG.rateLimit, ...(msg.config?.rateLimit || {}) },
        rollover: { ...DEFAULT_CONFIG.rollover, ...(msg.config?.rollover || {}) },
      };
      saveConfig();
      broadcastToDeepSeekTabs({ type: 'CONFIG_UPDATED', config });
      addDiagnostic('info', 'Настройки обновлены пользователем');
      sendResponse({ ok: true });
      return false;

    case 'TEST_MCP_SERVER':
      testMcpServer(msg.server)
        .then(result => sendResponse(result))
        .catch(err => sendResponse({ ok: false, error: err.message }));
      return true;

    case 'REFRESH_TOOLS':
      refreshAllTools()
        .then(tools => {
          config.cachedTools = tools;
          saveConfig();
          broadcastToDeepSeekTabs({ type: 'TOOLS_REFRESHED', tools });
          addDiagnostic('success', `Кэш инструментов обновлен: найдено ${tools.length} инстр.`);
          sendResponse({ ok: true, tools });
        })
        .catch(err => {
          addDiagnostic('error', `Ошибка обновления инструментов: ${err.message}`);
          sendResponse({ ok: false, error: err.message });
        });
      return true;

    case 'EXECUTE_TOOL_CALLS':
      executeToolCallsWithRateLimit(msg.calls)
        .then(results => sendResponse({ results }))
        .catch(err => {
          addDiagnostic('error', `Критический сбой выполнения: ${err.message}`);
          sendResponse({ results: [], error: err.message });
        });
      return true;

    case 'TRIGGER_SESSION_ROLLOVER':
      handleSessionRollover(msg.sessionId, msg.headers)
        .then(res => sendResponse(res))
        .catch(err => {
          addDiagnostic('error', `Сбой авто-ролловера: ${err.message}`);
          sendResponse({ ok: false, error: err.message });
        });
      return true;

    case 'OPEN_SIDE_PANEL':
      openSidePanel(sender, msg)
        .then(res => sendResponse(res))
        .catch(err => sendResponse({ ok: false, error: err.message }));
      return true;

    case 'UPDATE_SERVER':
      updateServer(msg.server)
        .then(res => sendResponse(res))
        .catch(err => sendResponse({ ok: false, error: err.message }));
      return true;

    case 'GET_SERVER_CURL': {
      const srv = (config.servers || []).find(s => s.id === msg.serverId) || msg.server;
      if (srv) {
        const initReq = createJsonRpcRequest('initialize', {
          protocolVersion: MCP_SUPPORTED_VERSIONS[0],
          capabilities: {},
          clientInfo: { name: 'DeepSeek MCP Lite', version: '0.4.0' },
        });
        const headers = buildHeaders(srv);
        const curl = generateCurlCommand(srv.url, 'POST', headers, initReq);
        sendResponse({ ok: true, curl });
      } else {
        sendResponse({ ok: false, error: 'Сервер не найден' });
      }
      return false;
    }

    case 'NATIVE_CDP_SUBMIT': {
      const tabId = sender.tab?.id;
      if (!tabId) {
        sendResponse({ ok: false, error: 'No sender tab id' });
        return true;
      }
      const { x, y, inputX, inputY } = msg.payload || {};
      dispatchNativeCdpSubmission(tabId, x, y, inputX, inputY)
        .then(res => sendResponse(res))
        .catch(err => sendResponse({ ok: false, error: err.message }));
      return true;
    }

    case 'TOGGLE_FLOATING_WIDGET':
      broadcastToDeepSeekTabs({ type: 'TOGGLE_FLOATING_WIDGET', show: msg.show });
      sendResponse({ ok: true });
      return false;

    case 'WIDGET_VISIBILITY_CHANGED':
      chrome.runtime.sendMessage({ type: 'WIDGET_VISIBILITY_CHANGED', show: msg.show }).catch(() => {});
      sendResponse({ ok: true });
      return false;

    default:
      return false;
  }
});

async function broadcastToDeepSeekTabs(message) {
  const tabs = await chrome.tabs.query({ url: 'https://chat.deepseek.com/*' });
  for (const tab of tabs) {
    chrome.tabs.sendMessage(tab.id, message).catch(() => {});
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// NATIVE CDP SUBMISSION VIA CHROME DEVTOOLS PROTOCOL
// ═══════════════════════════════════════════════════════════════════════════

async function dispatchNativeCdpSubmission(tabId, x, y, inputX, inputY) {
  addDiagnostic('info', `Запуск аппаратной отправки через CDP: send=(${Math.round(x||0)}, ${Math.round(y||0)}), input=(${Math.round(inputX||0)}, ${Math.round(inputY||0)})`);

  const target = { tabId };
  let attached = false;

  try {
    await chrome.debugger.attach(target, '1.3');
    attached = true;
  } catch (err) {
    if (err.message?.includes('already attached')) {
      attached = true;
    } else {
      addDiagnostic('warn', `Не удалось подключить CDP debugger: ${err.message}`);
      return { ok: false, error: `CDP attach failed: ${err.message}` };
    }
  }

  try {
    // 1. Аппаратный клик в поле ввода (textarea), чтобы гарантировать фокус
    if (typeof inputX === 'number' && typeof inputY === 'number' && inputX > 0 && inputY > 0) {
      addDiagnostic('info', `CDP: Аппаратный фокус поля ввода (${Math.round(inputX)}, ${Math.round(inputY)})...`);
      await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mousePressed',
        x: Math.round(inputX),
        y: Math.round(inputY),
        button: 'left',
        buttons: 1,
        clickCount: 1,
      });
      await new Promise(r => setTimeout(r, 40));
      await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mouseReleased',
        x: Math.round(inputX),
        y: Math.round(inputY),
        button: 'left',
        buttons: 0,
        clickCount: 1,
      });
      await new Promise(r => setTimeout(r, 60));
    }

    // 2. Аппаратное нажатие клавиши Enter (isTrusted: true в сфокусированном поле)
    addDiagnostic('info', 'CDP: Аппаратное нажатие клавиши Enter (isTrusted: true)...');
    await chrome.debugger.sendCommand(target, 'Input.dispatchKeyEvent', {
      type: 'rawKeyDown',
      windowsVirtualKeyCode: 13,
      nativeVirtualKeyCode: 13,
      macCharCode: 13,
      unmodifiedText: '\r',
      text: '\r',
      key: 'Enter',
      code: 'Enter',
    });

    await chrome.debugger.sendCommand(target, 'Input.dispatchKeyEvent', {
      type: 'char',
      text: '\r',
      unmodifiedText: '\r',
    });

    await chrome.debugger.sendCommand(target, 'Input.dispatchKeyEvent', {
      type: 'keyUp',
      windowsVirtualKeyCode: 13,
      nativeVirtualKeyCode: 13,
      key: 'Enter',
      code: 'Enter',
    });

    // 3. Аппаратный клик мыши по координатам кнопки отправки (дублирующая отправка)
    if (typeof x === 'number' && typeof y === 'number' && x > 0 && y > 0) {
      await new Promise(r => setTimeout(r, 80));
      addDiagnostic('info', `CDP: Клик по кнопке отправки (${Math.round(x)}, ${Math.round(y)})...`);

      await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mouseMoved',
        x: Math.round(x),
        y: Math.round(y),
      });
      await new Promise(r => setTimeout(r, 40));
      await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mousePressed',
        x: Math.round(x),
        y: Math.round(y),
        button: 'left',
        buttons: 1,
        clickCount: 1,
      });
      await new Promise(r => setTimeout(r, 60));
      await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mouseReleased',
        x: Math.round(x),
        y: Math.round(y),
        button: 'left',
        buttons: 0,
        clickCount: 1,
      });
    }

    addDiagnostic('success', '✓ CDP: Аппаратная отправка (Фокус + Enter + Клик) выполнена!');
    return { ok: true };

  } catch (err) {
    addDiagnostic('error', `Ошибка отправки событий через CDP: ${err.message}`);
    return { ok: false, error: err.message };
  } finally {
    // Отключаем дебаггер с небольшой задержкой, чтобы исчезла желтая плашка
    setTimeout(async () => {
      try {
        if (attached) {
          await chrome.debugger.detach(target);
        }
      } catch {}
    }, 400);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  SESSION BACKUP, COMPACTION & ROLLOVER
// ═══════════════════════════════════════════════════════════════════════════

async function handleSessionRollover(sessionId, authHeaders = {}) {
  addDiagnostic('warn', `Запуск архивации и компактизации сессии ${sessionId}...`);

  if (!sessionId) {
    throw new Error('ID текущей сессии не определен');
  }

  // 1. Fetch full conversation history from DeepSeek
  const historyUrl = `https://chat.deepseek.com/api/v0/chat/history_messages?chat_session_id=${sessionId}`;
  const response = await fetch(historyUrl, {
    method: 'GET',
    credentials: 'include',
    headers: {
      accept: 'application/json',
      ...authHeaders,
    },
  });

  if (!response.ok) {
    throw new Error(`Не удалось загрузить историю сессии: HTTP ${response.status}`);
  }

  const rawHistory = await response.json();
  const messages = extractMessages(rawHistory);
  const tokenEst = estimateTokenCount(messages);

  addDiagnostic('info', `История сессии загружена (${messages.length} сообщений, ~${tokenEst} токенов)`);

  // 2. Format backup file
  const isMarkdown = (config.rollover?.format || 'markdown') === 'markdown';
  const fileExt = isMarkdown ? 'md' : 'json';
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `DeepSeek_Backup_${sessionId}_${timestamp}.${fileExt}`;

  const fileContent = isMarkdown
    ? formatSessionToMarkdown(sessionId, rawHistory)
    : formatSessionToJson(sessionId, rawHistory);

  // 3. Save to disk via chrome.downloads (or DOM Blob fallback for large sessions)
  if (config.rollover?.autoDownload !== false) {
    let downloadSucceeded = false;
    const isLarge = fileContent.length >= 1500000;

    if (!isLarge) {
      const dataUri = `data:text/${isMarkdown ? 'markdown' : 'json'};charset=utf-8,` + encodeURIComponent(fileContent);
      try {
        await chrome.downloads.download({
          url: dataUri,
          filename,
          saveAs: false,
        });
        downloadSucceeded = true;
        addDiagnostic('success', `Полная копия диалога сохранена на диск: ${filename}`);
      } catch (err) {
        addDiagnostic('warn', `Авто-скачивание через chrome.downloads не удалось (${err.message}). Пробуем DOM Blob...`);
      }
    }

    if (!downloadSucceeded) {
      // Direct DOM Blob download fallback via content script
      await broadcastToDeepSeekTabs({
        type: 'TRIGGER_DOM_DOWNLOAD',
        payload: {
          content: fileContent,
          filename,
          mimeType: isMarkdown ? 'text/markdown;charset=utf-8' : 'application/json;charset=utf-8',
        },
      });
    }
  }

  // 4. Create Compacted continuation prompt
  const compactedPrompt = compactSessionHistory(sessionId, rawHistory, filename);

  // 5. Create a new session via DeepSeek API
  let newSessionId = null;
  try {
    const createResp = await fetch('https://chat.deepseek.com/api/v0/chat_session/create', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'content-type': 'application/json',
        ...authHeaders,
      },
      body: JSON.stringify({}),
    });

    if (createResp.ok) {
      const createData = await createResp.json();
      newSessionId = createData?.data?.biz_data?.id;
    }
  } catch (err) {
    addDiagnostic('warn', `Не удалось создать сессию через API (${err.message}), будет выполнен переход на главную`);
  }

  // 6. Save pending rollover prompt into chrome.storage.local
  await chrome.storage.local.set({
    pendingRollover: {
      fromSessionId: sessionId,
      targetSessionId: newSessionId,
      prompt: compactedPrompt,
      createdAt: Date.now(),
    },
  });

  const newUrl = newSessionId
    ? `https://chat.deepseek.com/a/chat/s/${newSessionId}`
    : 'https://chat.deepseek.com/';

  addDiagnostic('success', `Новая сессия подготовлена (${newSessionId || 'новый чат'}). Контекст перенесен.`);

  return {
    ok: true,
    sessionId,
    newSessionId,
    newUrl,
    filename,
    tokenEst,
    compactedPrompt,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
//  MCP CLIENT (JSON-RPC 2.0 over HTTP / SSE / Localhost)
// ═══════════════════════════════════════════════════════════════════════════

const MCP_SUPPORTED_VERSIONS = ['2025-03-26', '2024-11-05'];

function createJsonRpcRequest(method, params) {
  return {
    jsonrpc: '2.0',
    id: crypto.randomUUID(),
    method,
    ...(params ? { params } : {}),
  };
}

async function mcpFetch(url, body, headers = {}, timeoutMs = 30000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const isNotification = body && !body.id;

  const requestHeaders = {
    'content-type': 'application/json',
    'accept': 'application/json, text/event-stream',
    ...headers,
  };
  const curlStr = generateCurlCommand(url, 'POST', requestHeaders, body);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: requestHeaders,
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    const respHeaders = {};
    try {
      response.headers.forEach((v, k) => { respHeaders[k] = v; });
    } catch { /* ignore */ }

    if (!response.ok) {
      const errText = await response.text().catch(() => '');
      const httpTrace = {
        url,
        method: 'POST',
        requestHeaders,
        requestBody: body,
        responseStatus: response.status,
        responseStatusText: response.statusText,
        responseHeaders: respHeaders,
        responseBody: errText,
        curl: curlStr,
      };

      let reason = `HTTP ${response.status} ${response.statusText}`;
      if (response.status === 401 || response.status === 403) {
        reason += ' (Ошибка авторизации: проверьте Bearer Token)';
      } else if (response.status === 404) {
        reason += ` (Эндпоинт не найден: проверьте URL ${url}, возможно требуется путь /sse)`;
      }
      if (errText) {
        reason += `\nОтвет: ${errText.slice(0, 300)}`;
      }

      const err = new Error(reason);
      err.httpTrace = httpTrace;
      throw err;
    }

    if (response.status === 204) {
      return null;
    }

    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('text/event-stream')) {
      return await readSseResponse(response);
    }

    const text = await response.text();
    if (!text.trim()) {
      if (isNotification) return null;
      const err = new Error('MCP сервер вернул пустой ответ (0 байт) вместо JSON-RPC');
      err.httpTrace = {
        url,
        method: 'POST',
        requestHeaders,
        requestBody: body,
        responseStatus: response.status,
        responseStatusText: response.statusText,
        responseHeaders: respHeaders,
        responseBody: '',
        curl: curlStr,
      };
      throw err;
    }

    try {
      return JSON.parse(text);
    } catch {
      const err = new Error(`Некорректный JSON от MCP сервера: ${text.slice(0, 150)}`);
      err.httpTrace = {
        url,
        method: 'POST',
        requestHeaders,
        requestBody: body,
        responseStatus: response.status,
        responseStatusText: response.statusText,
        responseHeaders: respHeaders,
        responseBody: text,
        curl: curlStr,
      };
      throw err;
    }
  } catch (err) {
    if (err.name === 'AbortError') {
      const timeoutErr = new Error(`Таймаут обращения к MCP серверу (${timeoutMs} мс). Сервер не ответил.`);
      timeoutErr.httpTrace = {
        url,
        method: 'POST',
        requestHeaders,
        requestBody: body,
        error: 'AbortError (Timeout)',
        curl: curlStr,
      };
      throw timeoutErr;
    }
    if (err instanceof TypeError && err.message.includes('fetch')) {
      const netErr = new Error(`Не удалось подключиться к ${url} (Connection refused). Проверьте, запущен ли сервер на этом порту.`);
      netErr.httpTrace = {
        url,
        method: 'POST',
        requestHeaders,
        requestBody: body,
        error: err.message,
        curl: curlStr,
      };
      throw netErr;
    }
    if (!err.httpTrace) {
      err.httpTrace = {
        url,
        method: 'POST',
        requestHeaders,
        requestBody: body,
        error: err.message,
        curl: curlStr,
      };
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

async function readSseResponse(response) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  const deadline = Date.now() + 30000;

  while (Date.now() < deadline) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const events = parseSseEvents(buffer);
    buffer = events.remainder;

    for (const event of events.events) {
      try {
        const data = JSON.parse(event.data);
        if (data.jsonrpc === '2.0' && (data.result !== undefined || data.error !== undefined)) {
          await reader.cancel();
          return data;
        }
      } catch { /* skip non-json */ }
    }
  }

  throw new Error('SSE-поток завершился без ответа JSON-RPC');
}

function parseSseEvents(buffer) {
  const events = [];
  const blocks = buffer.split(/\n\n/);
  const remainder = blocks.pop() || '';

  for (const block of blocks) {
    const lines = block.split('\n');
    let event = 'message';
    const dataLines = [];
    for (const line of lines) {
      if (line.startsWith('event:')) event = line.slice(6).trim();
      if (line.startsWith('data:')) dataLines.push(line.slice(5).trim());
    }
    if (dataLines.length > 0) {
      events.push({ event, data: dataLines.join('\n') });
    }
  }

  return { events, remainder };
}

function unwrapResponse(response, errorLabel) {
  if (!response) return null;
  if (response.error) {
    throw new Error(`[${errorLabel}] Ошибка MCP: [${response.error.code}] ${response.error.message}`);
  }
  return response.result;
}

function buildHeaders(server, sessionState = {}) {
  const headers = {};

  if (server.secrets?.bearer) {
    headers['Authorization'] = `Bearer ${server.secrets.bearer}`;
  } else if (server.secrets?.basic) {
    headers['Authorization'] = `Basic ${btoa(server.secrets.basic)}`;
  }

  if (server.headers) {
    for (const [k, v] of Object.entries(server.headers)) {
      headers[k] = v;
    }
  }

  if (sessionState.protocolVersion) {
    headers['MCP-Protocol-Version'] = sessionState.protocolVersion;
  }

  if (sessionState.sessionId) {
    headers['Mcp-Session-Id'] = sessionState.sessionId;
  }

  return headers;
}

async function mcpInitialize(server) {
  const sessionState = {};
  const headers = buildHeaders(server, sessionState);
  const response = await mcpFetch(
    server.url,
    createJsonRpcRequest('initialize', {
      protocolVersion: MCP_SUPPORTED_VERSIONS[0],
      capabilities: {},
      clientInfo: { name: 'DeepSeek MCP Lite', version: '0.3.0' },
    }),
    headers,
    config.rateLimit.timeoutMs,
  );

  const result = unwrapResponse(response, 'initialize');
  sessionState.protocolVersion = result.protocolVersion || MCP_SUPPORTED_VERSIONS[0];

  await mcpFetch(
    server.url,
    { jsonrpc: '2.0', method: 'notifications/initialized' },
    buildHeaders(server, sessionState),
    5000,
  ).catch(() => {});

  return { result, sessionState };
}

async function mcpListTools(server, sessionState) {
  const headers = buildHeaders(server, sessionState);
  const tools = [];
  let cursor;

  do {
    const params = cursor ? { cursor } : undefined;
    const response = await mcpFetch(
      server.url,
      createJsonRpcRequest('tools/list', params),
      headers,
      config.rateLimit.timeoutMs,
    );
    const result = unwrapResponse(response, 'tools/list');
    const nextTools = Array.isArray(result?.tools) ? result.tools : [];
    tools.push(...nextTools);
    cursor = result?.nextCursor || undefined;
  } while (cursor && tools.length < 200);

  return tools;
}

async function mcpCallTool(server, sessionState, toolName, args) {
  const headers = buildHeaders(server, sessionState);
  const response = await mcpFetch(
    server.url,
    createJsonRpcRequest('tools/call', { name: toolName, arguments: args }),
    headers,
    config.rateLimit.timeoutMs,
  );
  return unwrapResponse(response, 'tools/call');
}

async function testMcpServer(server) {
  const startedAt = Date.now();
  const initReq = createJsonRpcRequest('initialize', {
    protocolVersion: MCP_SUPPORTED_VERSIONS[0],
    capabilities: {},
    clientInfo: { name: 'DeepSeek MCP Lite', version: '0.4.0' },
  });
  const headers = buildHeaders(server);
  const curl = generateCurlCommand(server.url, 'POST', headers, initReq);

  addDiagnostic('info', `Тестирование соединения с "${server.name}" (${server.url})...`, null, {
    url: server.url,
    method: 'POST',
    requestHeaders: headers,
    requestBody: initReq,
    curl,
  });

  try {
    const { result, sessionState } = await mcpInitialize(server);
    const tools = await mcpListTools(server, sessionState);
    const latencyMs = Date.now() - startedAt;

    const httpTrace = {
      url: server.url,
      method: 'POST',
      requestHeaders: headers,
      requestBody: initReq,
      responseStatus: 200,
      responseStatusText: 'OK',
      responseBody: JSON.stringify(result, null, 2),
      curl,
    };

    addDiagnostic('success', `Сервер "${server.name}" ответил за ${latencyMs}мс, найдено ${tools.length} инстр.`, null, httpTrace);

    // Auto-update cachedTools for active server so tools are immediately usable
    if (server.id && server.id !== 'temp-test' && Array.isArray(tools)) {
      const otherTools = (config.cachedTools || []).filter(t => t.serverId !== server.id);
      const newTools = tools.map(t => ({
        name: t.name,
        description: t.description || t.name,
        inputSchema: t.inputSchema || { type: 'object', properties: {} },
        serverId: server.id,
      }));
      config.cachedTools = [...otherTools, ...newTools];
      saveConfig();
      broadcastToDeepSeekTabs({ type: 'TOOLS_REFRESHED', tools: config.cachedTools });
    }

    return {
      ok: true,
      latencyMs,
      serverInfo: result.serverInfo || {},
      protocolVersion: result.protocolVersion,
      toolCount: tools.length,
      tools: tools.map(t => ({
        name: t.name,
        description: t.description || '',
      })),
      httpTrace,
      curl,
    };
  } catch (err) {
    const latencyMs = Date.now() - startedAt;
    const httpTrace = err.httpTrace || {
      url: server.url,
      method: 'POST',
      requestHeaders: headers,
      requestBody: initReq,
      error: err.message,
      curl,
    };

    addDiagnostic('error', `Сбой проверки "${server.name}": ${err.message}`, null, httpTrace);
    return {
      ok: false,
      latencyMs,
      error: err.message,
      httpTrace,
      curl,
    };
  }
}

async function updateServer(updatedServer) {
  if (!updatedServer || !updatedServer.id) {
    throw new Error('ID сервера не указан');
  }

  const idx = (config.servers || []).findIndex(s => s.id === updatedServer.id);
  if (idx === -1) {
    throw new Error('Сервер не найден');
  }

  config.servers[idx] = {
    ...config.servers[idx],
    ...updatedServer,
  };

  saveConfig();
  broadcastToDeepSeekTabs({ type: 'CONFIG_UPDATED', config });

  // Invalidate old session
  serverSessions.delete(updatedServer.id);

  // Refresh tools for active servers
  try {
    const tools = await refreshAllTools();
    config.cachedTools = tools;
    saveConfig();
    broadcastToDeepSeekTabs({ type: 'TOOLS_REFRESHED', tools });
  } catch { /* ignore */ }

  addDiagnostic('info', `Сервер "${updatedServer.name}" успешно обновлен`);
  return { ok: true, server: config.servers[idx] };
}

async function openSidePanel(sender, msg = {}) {
  const windowId = msg.windowId || sender?.tab?.windowId;
  if (chrome.sidePanel?.open && windowId) {
    try {
      await chrome.sidePanel.open({ windowId });
      return { ok: true, mode: 'sidePanel' };
    } catch (err) {
      console.warn('[MCP] chrome.sidePanel.open failed:', err);
    }
  }

  // Fallback to separate popup window
  const win = await chrome.windows.create({
    url: chrome.runtime.getURL('src/popup.html?mode=window'),
    type: 'popup',
    width: 520,
    height: 780,
  });
  return { ok: true, mode: 'window', windowId: win.id };
}

const serverSessions = new Map();

async function refreshAllTools() {
  const allTools = [];

  for (const server of config.servers) {
    if (!server.enabled) continue;
    try {
      let sessionState = serverSessions.get(server.id);
      if (!sessionState) {
        const init = await mcpInitialize(server);
        sessionState = init.sessionState;
        serverSessions.set(server.id, sessionState);
      }

      const tools = await mcpListTools(server, sessionState);
      for (const tool of tools) {
        allTools.push({
          name: tool.name,
          description: tool.description || tool.name,
          inputSchema: tool.inputSchema || { type: 'object', properties: {} },
          serverId: server.id,
        });
      }
    } catch (err) {
      addDiagnostic('warn', `Не удалось загрузить инструменты сервера "${server.name}": ${err.message}`);
      serverSessions.delete(server.id);
    }
  }

  return allTools;
}

// ═══════════════════════════════════════════════════════════════════════════
//  RATE LIMITER WITH HUMAN JITTER
// ═══════════════════════════════════════════════════════════════════════════

async function executeToolCallsWithRateLimit(calls) {
  const results = [];
  const rl = config.rateLimit;

  for (const call of calls) {
    const now = Date.now();
    callTimestamps = callTimestamps.filter(t => now - t < 60000);
    if (callTimestamps.length >= rl.maxCallsPerMinute) {
      const waitMs = Math.max(1000, (callTimestamps[0] + 60000) - now);
      addDiagnostic('warn', `Лимит ${rl.maxCallsPerMinute} вызовов/мин. Ожидание ${Math.ceil(waitMs / 1000)}с для защиты от бана...`);
      await sleep(waitMs);
    }

    if (results.length > 0 && rl.delayBetweenCallsMs > 0) {
      const jitter = Math.floor((Math.random() * 0.5 - 0.25) * rl.delayBetweenCallsMs);
      const finalDelay = Math.max(500, rl.delayBetweenCallsMs + jitter);
      addDiagnostic('info', `Троттлинг: пауза ${finalDelay}мс (с джиттером) перед следующим вызовом...`);
      await sleep(finalDelay);
    }

    const toolDef = config.cachedTools.find(t => t.name === call.name);
    if (!toolDef) {
      const msg = `Инструмент "${call.name}" не зарегистрирован ни на одном MCP сервере`;
      addDiagnostic('error', msg);
      results.push({
        name: call.name,
        ok: false,
        summary: 'Неизвестный инструмент',
        error: msg,
        detail: '',
      });
      continue;
    }

    const server = config.servers.find(s => s.id === toolDef.serverId);
    if (!server || !server.enabled) {
      const msg = `Сервер для инструмента "${call.name}" отключен или удален`;
      addDiagnostic('warn', msg);
      results.push({
        name: call.name,
        ok: false,
        summary: 'Сервер отключен',
        error: msg,
        detail: '',
      });
      continue;
    }

    const startedAt = Date.now();
    callTimestamps.push(startedAt);
    addDiagnostic('info', `Запуск: ${call.name} на "${server.name}"...`);

    try {
      let sessionState = serverSessions.get(server.id);
      if (!sessionState) {
        const init = await mcpInitialize(server);
        sessionState = init.sessionState;
        serverSessions.set(server.id, sessionState);
      }

      const result = await mcpCallTool(server, sessionState, call.name, call.payload);
      const detail = formatToolResult(result);
      const durationMs = Date.now() - startedAt;

      const truncated = detail.length > rl.maxResultBytes
        ? detail.slice(0, rl.maxResultBytes) + '\n...[truncated: превышен лимит объема]'
        : detail;

      addDiagnostic('success', `Выполнен: ${call.name} за ${durationMs}мс`);

      results.push({
        name: call.name,
        ok: !result?.isError,
        summary: result?.isError ? 'Инструмент вернул ошибку' : 'Инструмент успешно выполнен',
        detail: truncated,
        durationMs,
      });
    } catch (err) {
      serverSessions.delete(server.id);
      addDiagnostic('warn', `Сбой вызова ${call.name} (${err.message}). Повторная попытка с новым подключением...`);

      try {
        const init = await mcpInitialize(server);
        serverSessions.set(server.id, init.sessionState);
        const result = await mcpCallTool(server, init.sessionState, call.name, call.payload);
        const detail = formatToolResult(result);
        const durationMs = Date.now() - startedAt;

        addDiagnostic('success', `Успешный повтор: ${call.name} за ${durationMs}мс`);

        results.push({
          name: call.name,
          ok: !result?.isError,
          summary: result?.isError ? 'Ошибка (повтор)' : 'Выполнен (повтор)',
          detail: detail.slice(0, rl.maxResultBytes),
          durationMs,
        });
      } catch (retryErr) {
        const durationMs = Date.now() - startedAt;
        addDiagnostic('error', `Ошибка вызова ${call.name}: ${retryErr.message}`);
        results.push({
          name: call.name,
          ok: false,
          summary: 'Ошибка вызова',
          error: retryErr.message,
          detail: '',
          durationMs,
        });
      }
    }
  }

  return results;
}

function formatToolResult(result) {
  if (!result) return 'null';
  if (result.structuredContent !== undefined) {
    return JSON.stringify(result.structuredContent, null, 2);
  }
  if (Array.isArray(result.content)) {
    return result.content
      .map(block => {
        if (block.type === 'text' && block.text) return block.text;
        if (block.type === 'resource' && block.text) return block.text;
        return JSON.stringify(block);
      })
      .join('\n');
  }
  return JSON.stringify(result);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

console.log('[DeepSeek MCP Lite] Background service worker initialized with session rollover');
