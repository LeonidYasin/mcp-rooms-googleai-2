// ═══════════════════════════════════════════════════════════════════════════
// DeepSeek MCP Lite — Content Script (isolated world)
// ═══════════════════════════════════════════════════════════════════════════
// STEALTH & CONTEXT CONTINUITY:
//   - Closed Shadow DOM isolation
//   - Token usage counter & auto-compaction rollover orchestrator
//   - Seamless navigation to new session with context continuation
// ═══════════════════════════════════════════════════════════════════════════

(function () {
  'use strict';

  const DS_MCP_CHANNEL = 'ds-mcp-lite';

  // ── Create stealth host with closed shadow DOM ─────────────────────────
  const host = document.createElement('div');
  host.style.cssText = 'all: initial; position: fixed; z-index: 2147483647; pointer-events: none;';
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: 'closed' });

  // ── Floating Control & Diagnostics Widget ──────────────────────────────
  const badge = document.createElement('div');
  badge.style.pointerEvents = 'auto';
  badge.innerHTML = `
    <style>
      .ds-widget {
        position: fixed;
        top: 70px;
        right: 20px;
        bottom: auto;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 12px;
        background: #0f172a;
        color: #f1f5f9;
        border: 1px solid #334155;
        border-radius: 10px;
        padding: 10px 14px;
        min-width: 320px;
        max-width: 440px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.6);
        user-select: none;
        box-sizing: border-box;
      }
      .ds-widget.minimized .ds-body {
        display: none;
      }
      .ds-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: 600;
        gap: 8px;
        cursor: grab;
      }
      .status-pill {
        display: inline-flex;
        align-items: center;
        font-size: 11px;
        padding: 2px 8px;
        border-radius: 9999px;
        background: #1e293b;
        border: 1px solid #334155;
      }
      .token-pill {
        display: inline-flex;
        align-items: center;
        font-size: 10px;
        padding: 2px 6px;
        border-radius: 9999px;
        background: #1e293b;
        color: #94a3b8;
        border: 1px solid #334155;
        cursor: help;
      }
      .token-pill.warning {
        background: #451a03;
        border-color: #f59e0b;
        color: #fde68a;
      }
      .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        margin-right: 6px;
      }
      .status-dot.off { background: #64748b; }
      .status-dot.on { background: #10b981; }
      .status-dot.busy { background: #f59e0b; animation: ds-pulse 1s infinite; }
      .status-dot.error { background: #ef4444; }
      @keyframes ds-pulse { 0%,100% { opacity:1; } 50% { opacity:0.3; } }
      .toolbar-btns {
        display: flex;
        gap: 4px;
      }
      .btn-icon {
        background: none; border: none; color: #94a3b8;
        cursor: pointer; font-size: 13px; padding: 2px 6px;
        border-radius: 4px;
      }
      .btn-icon:hover { color: #fff; background: #334155; }
      .alert-box {
        margin-top: 8px;
        border-radius: 6px;
        padding: 8px 10px;
        font-size: 11px;
      }
      .alert-confirm {
        background: #1e293b;
        border: 1px solid #f59e0b;
      }
      .alert-circuit {
        background: #450a0a;
        border: 1px solid #ef4444;
        color: #fca5a5;
      }
      .alert-rollover {
        background: #1e1b4b;
        border: 1px solid #6366f1;
        color: #c7d2fe;
      }
      .confirm-btns {
        display: flex; gap: 6px; margin-top: 8px;
      }
      .btn-act {
        padding: 4px 10px; border: none; border-radius: 4px;
        font-size: 11px; cursor: pointer; font-weight: 500;
      }
      .btn-approve { background: #10b981; color: white; }
      .btn-skip { background: #ef4444; color: white; }
      .btn-rollover { background: #6366f1; color: white; }
      .log {
        max-height: 120px;
        overflow-y: auto;
        margin-top: 8px;
        font-size: 11px;
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        color: #94a3b8;
        border-top: 1px solid #1e293b;
        padding-top: 6px;
      }
      .log-entry { margin: 3px 0; word-break: break-all; line-height: 1.4; }
      .log-entry.ok { color: #34d399; }
      .log-entry.err { color: #f87171; }
      .log-entry.warn { color: #fbbf24; }
      .log-entry.info { color: #60a5fa; }
      .btn-settings-highlight {
        background: linear-gradient(135deg, #0284c7, #2563eb) !important;
        color: #fff !important;
        font-weight: 600 !important;
        font-size: 11px !important;
        padding: 2px 8px !important;
        border-radius: 5px !important;
        box-shadow: 0 1px 6px rgba(2, 132, 199, 0.4);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 3px;
      }
      .btn-settings-highlight:hover {
        background: linear-gradient(135deg, #0369a1, #1d4ed8) !important;
      }
      .log-time { color: #64748b; margin-right: 4px; font-size: 10px; }
      .audit-counter-pill {
        display: inline-flex;
        align-items: center;
        font-size: 10px;
        padding: 2px 6px;
        border-radius: 9999px;
        background: #1e293b;
        color: #94a3b8;
        border: 1px solid #334155;
        font-weight: 600;
        cursor: help;
      }
      .audit-counter-pill.active {
        background: #064e3b;
        color: #6ee7b7;
        border-color: #10b981;
      }
      .audit-card {
        margin-top: 8px;
        background: #0a0f1d;
        border: 1px solid #1e293b;
        border-radius: 6px;
        padding: 8px;
        font-size: 11px;
      }
      .audit-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 4px;
      }
      .audit-title {
        font-weight: 600;
        color: #38bdf8;
        font-size: 11px;
      }
      .audit-badge {
        font-size: 9px;
        padding: 1px 6px;
        border-radius: 9999px;
        font-weight: 600;
        background: #1e293b;
        color: #94a3b8;
      }
      .audit-badge.ok {
        background: #064e3b;
        color: #6ee7b7;
        border: 1px solid #10b981;
      }
      .audit-badge.err {
        background: #450a0a;
        color: #fca5a5;
        border: 1px solid #ef4444;
      }
      .audit-summary {
        color: #cbd5e1;
        font-size: 11px;
        line-height: 1.4;
        word-break: break-word;
      }
      .audit-btn-row {
        display: flex;
        gap: 6px;
        margin-top: 6px;
      }
      .btn-audit {
        background: #1e293b;
        border: 1px solid #334155;
        color: #cbd5e1;
        font-size: 10px;
        padding: 3px 8px;
        border-radius: 4px;
        cursor: pointer;
      }
      .btn-audit:hover {
        background: #334155;
        color: #fff;
      }
      .audit-drawer {
        margin-top: 6px;
        background: #020617;
        border: 1px solid #334155;
        border-radius: 4px;
        padding: 6px;
      }
      .audit-box-user {
        background: #0f172a;
        color: #93c5fd;
        padding: 4px 6px;
        border-radius: 3px;
        font-size: 10px;
        max-height: 60px;
        overflow-y: auto;
        word-break: break-word;
      }
      .audit-box-injected {
        background: #0f172a;
        color: #34d399;
        padding: 4px 6px;
        border-radius: 3px;
        font-size: 9px;
        max-height: 120px;
        overflow-y: auto;
        white-space: pre-wrap;
        word-break: break-all;
        margin: 0;
      }
    </style>
    <div class="ds-widget" id="ds-mcp-panel">
      <div class="ds-header">
        <div class="status-pill" id="ds-status-clickable" style="cursor:pointer" title="⚡ Нажмите, чтобы открыть боковую панель DeepSeek MCP">
          <span class="status-dot off" id="ds-mcp-dot"></span>
          <span id="ds-mcp-status-text">MCP: Отключен</span>
        </div>
        <div class="audit-counter-pill" id="ds-audit-counter" title="Счетчик успешно перехваченных и обогащенных запросов">🎯 0</div>
        <div class="token-pill" id="ds-token-indicator" title="Оценка объема сессии">~0 токенов</div>
        <div class="toolbar-btns">
          <button class="btn-icon btn-settings-highlight" id="ds-mcp-settings-btn" title="⚡ Нажмите, чтобы открыть постоянную боковую панель MCP (настройки и cURL)">⚙️ Панель</button>
          <button class="btn-icon" id="ds-mcp-rollover-btn" title="Архивировать сессию и открыть новую с компактизацией">📦</button>
          <button class="btn-icon" id="ds-mcp-copy-btn" title="Скопировать лог">📋</button>
          <button class="btn-icon" id="ds-mcp-clear-btn" title="Очистить лог">🗑</button>
          <button class="btn-icon" id="ds-mcp-min-btn" title="Свернуть / Развернуть">−</button>
          <button class="btn-icon" id="ds-mcp-close-widget-btn" title="Скрыть плавающий виджет с этой страницы (можно включить обратно в боковой панели)">✕</button>
        </div>
      </div>
      <div class="ds-body" id="ds-mcp-body">
        <div id="ds-mcp-alerts" style="display:none"></div>

        <!-- ── Live Objective Control Card ── -->
        <div class="audit-card" id="ds-audit-card">
          <div class="audit-header">
            <span class="audit-title">🎯 Контроль перехвата:</span>
            <span class="audit-badge" id="ds-audit-badge">⚪ Ожидание сообщения</span>
          </div>
          <div class="audit-summary" id="ds-audit-summary">
            Отправьте любое сообщение в чат DeepSeek — здесь мгновенно появится доказательство внедрения инструментов.
          </div>
          <div class="audit-btn-row" id="ds-audit-btn-row">
            <button class="btn-audit" id="ds-audit-submit-test-btn" style="background:linear-gradient(135deg, #059669, #10b981);color:#fff;font-weight:600" title="Вставить тестовую команду прямо в окно чата и отправить">▶ Отправить тест в чат</button>
            <button class="btn-audit" id="ds-audit-auto-test-btn" title="Прямой опрос потока API">⚡ Тест API</button>
            <button class="btn-audit" id="ds-audit-toggle-btn" style="display:none">👁 Что реально ушло</button>
            <button class="btn-audit" id="ds-audit-copy-raw-btn" style="display:none">📋 Копировать JSON</button>
          </div>
          <div id="ds-test-progress-bar" style="display:none;margin-top:6px;font-size:10px;padding:5px 7px;border-radius:4px;line-height:1.4"></div>
          <div class="audit-drawer" id="ds-audit-drawer" style="display:none">
            <div style="font-size:10px;font-weight:600;color:#60a5fa;margin-bottom:2px">Ваш ввод пользователем:</div>
            <div id="ds-audit-user-text" class="audit-box-user"></div>
            <div style="font-size:10px;font-weight:600;color:#34d399;margin:6px 0 2px">Блок MCP инструментов, переданный в DeepSeek:</div>
            <pre id="ds-audit-injected-text" class="audit-box-injected"></pre>
          </div>
        </div>

        <div class="log" id="ds-mcp-log"></div>
      </div>
    </div>
  `;
  shadow.appendChild(badge);

  const $ = (sel) => shadow.querySelector(sel);
  const panel = $('#ds-mcp-panel');

  // Drag & Drop support for the floating widget
  let isDragging = false;
  let dragStartX = 0;
  let dragStartY = 0;
  let widgetStartLeft = 0;
  let widgetStartTop = 0;

  const headerEl = shadow.querySelector('.ds-header');
  if (headerEl && panel) {
    headerEl.addEventListener('mousedown', (e) => {
      if (e.target.closest('button') || e.target.closest('.nav-btn') || e.target.closest('#ds-status-clickable') || e.target.closest('.header-btn')) return;
      isDragging = true;
      headerEl.style.cursor = 'grabbing';
      const rect = panel.getBoundingClientRect();
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      widgetStartLeft = rect.left;
      widgetStartTop = rect.top;

      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
      panel.style.left = `${widgetStartLeft}px`;
      panel.style.top = `${widgetStartTop}px`;
      e.preventDefault();
    });

    window.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - dragStartX;
      const dy = e.clientY - dragStartY;
      const newLeft = Math.max(10, Math.min(window.innerWidth - panel.offsetWidth - 10, widgetStartLeft + dx));
      const maxAllowedTop = Math.max(20, window.innerHeight - panel.offsetHeight - 240);
      const newTop = Math.max(10, Math.min(maxAllowedTop, widgetStartTop + dy));
      panel.style.left = `${newLeft}px`;
      panel.style.top = `${newTop}px`;
    });

    window.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        headerEl.style.cursor = 'grab';
        try {
          const rect = panel.getBoundingClientRect();
          chrome.storage?.local?.set({
            dsmcp_widget_pos: { left: Math.round(rect.left), top: Math.round(rect.top) },
          });
        } catch {}
      }
    });
  }

  // Restore saved widget position and visibility
  try {
    chrome.storage?.local?.get(['dsmcp_show_widget', 'dsmcp_widget_pos'], (data) => {
      if (data?.dsmcp_show_widget === false && panel) {
        panel.style.display = 'none';
      }
      if (data?.dsmcp_widget_pos && panel) {
        const { left, top } = data.dsmcp_widget_pos;
        if (typeof left === 'number' && typeof top === 'number') {
          panel.style.right = 'auto';
          panel.style.bottom = 'auto';
          const maxAllowedTop = Math.max(20, window.innerHeight - 340);
          panel.style.left = `${Math.max(10, Math.min(window.innerWidth - 340, left))}px`;
          panel.style.top = `${Math.max(10, Math.min(maxAllowedTop, top))}px`;
        }
      }
    });
  } catch {}

  // Toggle minimize
  $('#ds-mcp-min-btn').addEventListener('click', () => {
    panel.classList.toggle('minimized');
    $('#ds-mcp-min-btn').textContent = panel.classList.contains('minimized') ? '+' : '−';
  });

  // Close / hide floating widget completely from the page
  $('#ds-mcp-close-widget-btn')?.addEventListener('click', () => {
    panel.style.display = 'none';
    try {
      chrome.storage?.local?.set({ dsmcp_show_widget: false });
    } catch {}
    safeSendMessage({ type: 'WIDGET_VISIBILITY_CHANGED', show: false });
  });

  // Copy logs
  $('#ds-mcp-copy-btn').addEventListener('click', () => {
    const text = logHistory.map(e => `[${e.time}] [${e.level.toUpperCase()}] ${e.msg}`).join('\n');
    navigator.clipboard.writeText(text).then(() => {
      addLog('Лог скопирован в буфер обмена', 'info');
    });
  });

  // Clear logs
  $('#ds-mcp-clear-btn').addEventListener('click', () => {
    logHistory.length = 0;
    $('#ds-mcp-log').innerHTML = '';
    addLog('Лог очищен', 'info');
  });

  // Settings Side Panel Buttons
  const openSidePanelAction = () => {
    safeSendMessage({ type: 'OPEN_SIDE_PANEL' });
    addLog('Открытие боковой панели настроек...', 'info');
  };
  $('#ds-mcp-settings-btn').addEventListener('click', openSidePanelAction);
  $('#ds-status-clickable').addEventListener('click', openSidePanelAction);

  // Manual Rollover Button
  $('#ds-mcp-rollover-btn').addEventListener('click', () => {
    if (confirm('Архивировать эту сессию на диск, сжать контекст и открыть новую сессию?')) {
      window.postMessage({
        channel: DS_MCP_CHANNEL,
        type: 'MANUAL_ROLLOVER_TRIGGER',
      }, '*');
    }
  });

  // ── Objective Control Audit UI ─────────────────────────────────────────
  let interceptionCount = 0;
  let lastAudit = null;

  function updateAuditCard(audit) {
    if (!audit) return;
    lastAudit = audit;
    if (audit.injected) {
      interceptionCount++;
      const counter = $('#ds-audit-counter');
      if (counter) {
        counter.textContent = `🎯 ${interceptionCount}`;
        counter.classList.add('active');
      }
      const badge = $('#ds-audit-badge');
      if (badge) {
        badge.className = 'audit-badge ok';
        badge.textContent = `✓ ВНЕДРЕНО (${audit.toolCount} инстр.)`;
      }
      const sum = $('#ds-audit-summary');
      if (sum) {
        sum.innerHTML = `<strong>[${audit.time}]</strong> В исходящий запрос добавлено <strong>${audit.toolCount} инстр.</strong> (+${audit.injectedBytes} симв.) в <code>${escapeHtml(audit.url.split('?')[0])}</code>`;
      }
    } else {
      const badge = $('#ds-audit-badge');
      if (badge) {
        badge.className = 'audit-badge err';
        badge.textContent = '✗ НЕ ВНЕДРЕНО';
      }
      const sum = $('#ds-audit-summary');
      if (sum) {
        sum.innerHTML = `<strong>[${audit.time}]</strong> Запрос перехвачен, но инструменты не добавлены: <span style="color:#f87171">${escapeHtml(audit.failReason || 'Неизвестная причина')}</span>`;
      }
    }

    const btnToggle = $('#ds-audit-toggle-btn');
    if (btnToggle) btnToggle.style.display = 'inline-block';
    const btnCopy = $('#ds-audit-copy-raw-btn');
    if (btnCopy) btnCopy.style.display = 'inline-block';

    const uBox = $('#ds-audit-user-text');
    if (uBox) uBox.textContent = audit.userText || '(пусто)';

    const iBox = $('#ds-audit-injected-text');
    if (iBox) iBox.textContent = audit.injectedPatch || audit.failReason || '(нет добавленного блока)';
  }

  $('#ds-audit-submit-test-btn')?.addEventListener('click', () => {
    window.postMessage({
      channel: DS_MCP_CHANNEL,
      type: 'SUBMIT_CHAT_TEST_PROMPT',
      payload: {},
    }, '*');
    addLog('Запуск тестового вопроса прямо в поле ввода чата...', 'info');
  });

  $('#ds-audit-auto-test-btn')?.addEventListener('click', () => {
    window.postMessage({
      channel: DS_MCP_CHANNEL,
      type: 'START_CHAT_VERIFICATION',
      payload: {},
    }, '*');
    const bar = $('#ds-test-progress-bar');
    if (bar) {
      bar.style.display = 'block';
      bar.style.background = '#1e3a5f';
      bar.style.color = '#93c5fd';
      bar.style.border = '1px solid #3b82f6';
      bar.innerHTML = '<strong>[Шаг 1/4]</strong> Подготовка прямого сетевого потока API...';
    }
  });

  $('#ds-audit-toggle-btn')?.addEventListener('click', () => {
    const dr = $('#ds-audit-drawer');
    if (!dr) return;
    const isHidden = dr.style.display === 'none';
    dr.style.display = isHidden ? 'block' : 'none';
    $('#ds-audit-toggle-btn').textContent = isHidden ? '▲ Скрыть детали' : '👁 Что реально ушло в DeepSeek';
  });

  $('#ds-audit-copy-raw-btn')?.addEventListener('click', () => {
    if (!lastAudit?.rawBodySnippet) return;
    navigator.clipboard.writeText(lastAudit.rawBodySnippet).then(() => {
      addLog('Тело исходящего запроса скопировано в буфер', 'ok');
    });
  });

  function setStatus(dotClass, text) {
    const dot = $('#ds-mcp-dot');
    const label = $('#ds-mcp-status-text');
    dot.className = `status-dot ${dotClass}`;
    label.textContent = text;
  }

  const logHistory = [];
  function addLog(msg, level = 'info') {
    const time = new Date().toLocaleTimeString('ru', { hour12: false });
    logHistory.push({ time, level, msg });
    if (logHistory.length > 80) logHistory.shift();

    const log = $('#ds-mcp-log');
    const entry = document.createElement('div');
    const typeClass = level === 'success' ? 'ok' : level === 'error' ? 'err' : level;
    entry.className = `log-entry ${typeClass}`;
    entry.innerHTML = `<span class="log-time">[${time}]</span> ${escapeHtml(msg)}`;
    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  function safeSendMessage(message, callback) {
    try {
      if (!chrome.runtime?.id) {
        console.warn('[MCP Lite] Контекст расширения устарел. Пожалуйста, обновите страницу (F5).');
        return;
      }
      chrome.runtime.sendMessage(message, (res) => {
        const err = chrome.runtime.lastError;
        if (err) {
          if (err.message?.includes('context invalidated')) {
            console.warn('[MCP Lite] Расширение было перезагружено. Обновите вкладку (F5).');
            return;
          }
        }
        if (typeof callback === 'function') {
          callback(res);
        }
      });
    } catch (err) {
      if (err?.message?.includes('context invalidated')) {
        console.warn('[MCP Lite] Расширение было перезагружено. Обновите вкладку (F5).');
      } else {
        console.warn('[MCP Lite] safeSendMessage error:', err);
      }
    }
  }

  // ── Config State ───────────────────────────────────────────────────────
  let currentConfig = null;

  safeSendMessage({ type: 'GET_CONFIG' }, (response) => {
    if (response) {
      currentConfig = response;
      syncToMainWorld();
      updateStatusBadge();
    }
  });

  safeSendMessage({ type: 'GET_LAST_INTERCEPTION' }, (res) => {
    if (res?.audit) {
      if (res.totalCount) interceptionCount = res.totalCount - 1;
      updateAuditCard(res.audit);
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'CONFIG_UPDATED') {
      currentConfig = msg.config;
      syncToMainWorld();
      updateStatusBadge();
      addLog('Настройки обновлены', 'warn');
    }
    if (msg.type === 'TOOLS_REFRESHED') {
      if (currentConfig) currentConfig.cachedTools = msg.tools;
      syncToMainWorld();
      addLog(`Кэш инструментов обновлен (${msg.tools?.length || 0} инстр.)`, 'ok');
    }
    if (msg.type === 'DIAGNOSTIC_ENTRY') {
      addLog(msg.entry.message, msg.entry.level);
    }
    if (msg.type === 'TRIGGER_DOM_DOWNLOAD') {
      triggerDomBlobDownload(msg.payload.content, msg.payload.filename, msg.payload.mimeType);
    }
    if (msg.type === 'TRIGGER_CHAT_VERIFICATION') {
      window.postMessage({
        channel: DS_MCP_CHANNEL,
        type: 'START_CHAT_VERIFICATION',
        payload: { prompt: msg.prompt },
      }, '*');
      const bar = $('#ds-test-progress-bar');
      if (bar) {
        bar.style.display = 'block';
        bar.style.background = '#1e3a5f';
        bar.style.color = '#93c5fd';
        bar.style.border = '1px solid #3b82f6';
        bar.innerHTML = '<strong>[Шаг 1/4]</strong> Запуск авто-теста из боковой панели...';
      }
    }
    if (msg.type === 'TRIGGER_CHAT_SUBMIT_TEST') {
      window.postMessage({
        channel: DS_MCP_CHANNEL,
        type: 'SUBMIT_CHAT_TEST_PROMPT',
        payload: { prompt: msg.prompt },
      }, '*');
    }
    if (msg.type === 'TOGGLE_FLOATING_WIDGET') {
      if (panel) {
        panel.style.display = msg.show ? 'block' : 'none';
      }
    }
  });

  function triggerDomBlobDownload(content, filename, mimeType) {
    try {
      const blob = new Blob([content], { type: mimeType || 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.documentElement.appendChild(a);
      a.click();
      setTimeout(() => {
        if (a.parentNode) a.parentNode.removeChild(a);
        URL.revokeObjectURL(url);
      }, 2000);
      addLog(`Архив сохранен на диск (DOM Blob): ${filename}`, 'ok');
    } catch (err) {
      addLog(`Ошибка сохранения архива: ${err.message}`, 'err');
    }
  }

  function updateStatusBadge() {
    if (!currentConfig) return;
    if (currentConfig.enabled) {
      const toolCount = currentConfig.cachedTools?.length || 0;
      setStatus('on', `MCP: Готов (${toolCount} инстр.)`);
    } else {
      setStatus('off', 'MCP: Отключен');
    }
  }

  function syncToMainWorld() {
    if (!currentConfig) return;
    window.postMessage({
      channel: DS_MCP_CHANNEL,
      type: 'CONFIG_UPDATE',
      payload: {
        enabled: currentConfig.enabled,
        tools: currentConfig.cachedTools || [],
        maxConsecutiveTurns: currentConfig.rateLimit?.maxConsecutiveTurns ?? 5,
        preferDomInput: currentConfig.rateLimit?.preferDomInput ?? false,
        rollover: currentConfig.rollover,
      },
    }, '*');
  }

  // ── Handle events from main-world ──────────────────────────────────────
  window.addEventListener('message', async (e) => {
    if (e.source !== window || e.data?.channel !== DS_MCP_CHANNEL) return;
    const { type, payload } = e.data;

    if (type === 'MAIN_WORLD_READY') {
      syncToMainWorld();
      addLog('Синхронизация с контекстом чата выполнена', 'info');
    }

    if (type === 'VERIFICATION_STATUS_UPDATE') {
      const bar = $('#ds-test-progress-bar');
      if (bar) {
        bar.style.display = 'block';
        if (payload.ok) {
          bar.style.background = payload.step === 4 ? '#064e3b' : '#1e3a5f';
          bar.style.color = payload.step === 4 ? '#6ee7b7' : '#93c5fd';
          bar.style.border = payload.step === 4 ? '1px solid #10b981' : '1px solid #3b82f6';
        } else {
          bar.style.background = '#450a0a';
          bar.style.color = '#fca5a5';
          bar.style.border = '1px solid #ef4444';
        }
        bar.innerHTML = `<strong>[Шаг ${payload.step}/4]</strong> ${escapeHtml(payload.message)}`;
      }
      safeSendMessage({
        type: 'VERIFICATION_STATUS_BROADCAST',
        status: payload,
      });
    }

    if (type === 'INTERCEPTION_AUDIT') {
      updateAuditCard(payload);
      safeSendMessage({
        type: 'SAVE_LAST_INTERCEPTION',
        audit: payload,
        totalCount: interceptionCount,
      });
    }

    if (type === 'LOG_EVENT') {
      addLog(payload.message, payload.level);
    }

    if (type === 'TOKEN_USAGE_UPDATE') {
      const { tokens, threshold } = payload;
      const indicator = $('#ds-token-indicator');
      indicator.textContent = `~${(tokens / 1000).toFixed(1)}k токенов`;
      if (threshold && tokens >= threshold * 0.85) {
        indicator.classList.add('warning');
        indicator.title = `Внимание: объем сессии (~${tokens}) приближается к порогу (${threshold})`;
      } else {
        indicator.classList.remove('warning');
      }
    }

    if (type === 'START_ROLLOVER_PROCESS') {
      executeRolloverWorkflow(payload.sessionId, payload.headers);
    }

    if (type === 'CHECK_PENDING_ROLLOVER') {
      checkPendingRollover(payload.currentSessionId);
    }

    if (type === 'CIRCUIT_BREAKER_TRIGGERED') {
      showCircuitBreakerAlert(payload.turns, payload.max);
    }

    if (type === 'TOOL_CALLS_DETECTED') {
      const { calls, parentMessageId } = payload;
      addLog(`Запрос вызова: ${calls.map(c => c.name).join(', ')}`, 'warn');

      if (currentConfig?.rateLimit?.requireConfirmation) {
        showConfirmationUI(calls, (approved) => {
          if (approved) {
            executeAndContinue(calls, parentMessageId);
          } else {
            addLog('Пользователь отклонил запуск инструмента', 'warn');
            updateStatusBadge();
          }
        });
      } else {
        executeAndContinue(calls, parentMessageId);
      }
    }

    if (type === 'CONTINUATION_SUBMITTED') {
      addLog(`Продолжение отправлено в DeepSeek (${payload.method || 'UI'})`, 'ok');
      updateStatusBadge();
    }

    if (type === 'NATIVE_CDP_SUBMIT') {
      // Temporarily hide widget completely so it CANNOT intercept CDP hit-testing
      host.style.visibility = 'hidden';
      host.style.pointerEvents = 'none';

      addLog(`Запрос аппаратной отправки через CDP (send: x=${payload?.x}, y=${payload?.y})...`, 'info');
      safeSendMessage({
        type: 'NATIVE_CDP_SUBMIT',
        payload: payload,
      }, (res) => {
        setTimeout(() => {
          host.style.visibility = 'visible';
          host.style.pointerEvents = 'auto';
        }, 500);

        if (res?.ok) {
          addLog('✓ CDP: Аппаратная отправка выполнена успешно!', 'ok');
        } else {
          addLog(`⚠ CDP отправка: ${res?.error || 'сбой'}`, 'warn');
        }
        window.postMessage({
          channel: DS_MCP_CHANNEL,
          type: 'NATIVE_CDP_SUBMIT_RESULT',
          payload: res,
        }, '*');
      });
    }

    if (type === 'CONTINUATION_ERROR') {
      addLog(`Сбой отправки продолжения: ${payload.error}`, 'err');
      setStatus('error', 'Сбой отправки');
    }
  });

  // ── Session Rollover Execution ─────────────────────────────────────────
  function executeRolloverWorkflow(sessionId, headers) {
    setStatus('busy', 'Архивация сессии...');
    addLog(`Запуск авто-ролловера для сессии ${sessionId}...`, 'warn');

    safeSendMessage({
      type: 'TRIGGER_SESSION_ROLLOVER',
      sessionId,
      headers,
    }, (res) => {
      if (!res || !res.ok) {
        addLog(`Сбой ролловера: ${res?.error || 'неизвестная ошибка'}`, 'err');
        setStatus('error', 'Сбой ролловера');
        return;
      }

      addLog(`Диалог заархивирован в ${res.filename}`, 'ok');
      addLog('Контекст компактизирован. Переход в новую сессию...', 'info');

      // Auto-navigate to new session if configured
      if (currentConfig?.rollover?.autoNavigate !== false && res.newUrl) {
        setTimeout(() => {
          window.location.href = res.newUrl;
        }, 1200);
      }
    });
  }

  function checkPendingRollover(currentSessionId) {
    chrome.storage.local.get('pendingRollover', (data) => {
      const pending = data.pendingRollover;
      if (!pending || !pending.prompt) return;

      // Ensure this is recent (under 5 minutes)
      if (Date.now() - pending.createdAt > 300000) {
        chrome.storage.local.remove('pendingRollover');
        return;
      }

      // If we are in the target session or opened a new chat
      if (!pending.targetSessionId || pending.targetSessionId === currentSessionId || !currentSessionId) {
        addLog('Обнаружен перенесенный контекст, вставка в чат...', 'info');
        window.postMessage({
          channel: DS_MCP_CHANNEL,
          type: 'APPLY_PENDING_ROLLOVER',
          payload: { prompt: pending.prompt },
        }, '*');

        chrome.storage.local.remove('pendingRollover');
      }
    });
  }

  function showCircuitBreakerAlert(turns, max) {
    const alerts = $('#ds-mcp-alerts');
    alerts.style.display = 'block';
    alerts.className = 'alert-box alert-circuit';
    alerts.innerHTML = `
      <strong>🛡 Защита от бесконечного цикла</strong>
      <div>Модель вызвала инструменты ${turns} раз подряд (максимум ${max}). Цепочка остановлена во избежание перегрузки.</div>
      <button class="btn-act btn-skip" style="margin-top:6px" id="ds-btn-dismiss">Закрыть</button>
    `;
    alerts.querySelector('#ds-btn-dismiss').addEventListener('click', () => {
      alerts.style.display = 'none';
    });
  }

  function showConfirmationUI(calls, callback) {
    const alerts = $('#ds-mcp-alerts');
    alerts.style.display = 'block';
    alerts.className = 'alert-box alert-confirm';
    alerts.innerHTML = `
      <div><strong>Подтвердите запуск инструмента:</strong></div>
      <div style="margin: 4px 0; color:#fbbf24; font-family:monospace">${calls.map(c => c.name).join(', ')}</div>
      <div class="confirm-btns">
        <button class="btn-act btn-approve" id="ds-btn-approve">Запустить</button>
        <button class="btn-act btn-skip" id="ds-btn-skip">Пропустить</button>
      </div>
    `;

    alerts.querySelector('#ds-btn-approve').addEventListener('click', () => {
      alerts.style.display = 'none';
      callback(true);
    });

    alerts.querySelector('#ds-btn-skip').addEventListener('click', () => {
      alerts.style.display = 'none';
      callback(false);
    });
  }

  function executeAndContinue(calls, parentMessageId) {
    setStatus('busy', `Выполнение ${calls.length} инстр...`);

    safeSendMessage({
      type: 'EXECUTE_TOOL_CALLS',
      calls,
    }, (response) => {
      if (chrome.runtime?.lastError) {
        addLog(`Ошибка выполнения: ${chrome.runtime.lastError.message}`, 'err');
        setStatus('error', 'Ошибка');
        return;
      }

      const results = response?.results || [];
      for (const r of results) {
        addLog(`${r.name}: ${r.ok ? 'Успешно' : 'Ошибка'} (${r.durationMs || 0}мс)`, r.ok ? 'ok' : 'err');
      }

      window.postMessage({
        channel: DS_MCP_CHANNEL,
        type: 'TOOL_RESULTS_READY',
        payload: {
          results,
          parentMessageId,
        },
      }, '*');
    });
  }

  console.log('[DeepSeek MCP Lite] Content script v0.3.0 active with session rollover');
})();
