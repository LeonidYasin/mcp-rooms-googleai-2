// ═══════════════════════════════════════════════════════════════════════════
// DeepSeek MCP Lite — cURL & Config Utilities (Generator & Smart Importer)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Builds a valid shell cURL command string for terminal debugging.
 */
export function generateCurlCommand(url, method = 'POST', headers = {}, body = null) {
  const lines = [`curl -i -X ${method.toUpperCase()} "${url}"`];

  for (const [k, v] of Object.entries(headers || {})) {
    lines.push(`  -H "${k}: ${v}"`);
  }

  if (body) {
    const bodyStr = typeof body === 'string' ? body : JSON.stringify(body);
    lines.push(`  -d '${bodyStr.replace(/'/g, "'\\''")}'`);
  }

  return lines.join(' \\\n');
}

/**
 * Parses a raw cURL command pasted by the user into MCP server configuration.
 */
export function parseCurlCommand(rawStr) {
  if (!rawStr || typeof rawStr !== 'string') return null;

  // Flatten escaped linebreaks
  const s = rawStr.replace(/\\\r?\n/g, ' ').trim();

  // 1. Extract URL (http:// or https://)
  const urlMatch = s.match(/(?:['"])(https?:\/\/[^'"]+)(?:['"])|(?:^|\s)(https?:\/\/[^\s'"]+)/i);
  const url = (urlMatch ? (urlMatch[1] || urlMatch[2]) : '').trim();

  // 2. Extract Method
  const methodMatch = s.match(/(?:-X|--request)\s+['"]?([A-Z]+)['"]?/i);
  const method = methodMatch ? methodMatch[1].toUpperCase() : (s.includes(' -d ') || s.includes(' --data') ? 'POST' : 'GET');

  // 3. Extract Headers
  const headers = {};
  let bearerToken = '';
  const headerRegex = /(?:-H|--header)\s+(?:'([^']+)'|"([^"]+)")/g;
  let match;
  while ((match = headerRegex.exec(s)) !== null) {
    const headerLine = (match[1] || match[2] || '').trim();
    const colonIdx = headerLine.indexOf(':');
    if (colonIdx > -1) {
      const key = headerLine.slice(0, colonIdx).trim();
      const val = headerLine.slice(colonIdx + 1).trim();
      if (key.toLowerCase() === 'authorization' && /^bearer\s+/i.test(val)) {
        bearerToken = val.replace(/^bearer\s+/i, '').trim();
      } else {
        headers[key] = val;
      }
    }
  }

  // 4. Extract Body (if present)
  let body = '';
  const dataMatch = s.match(/(?:-d|--data|--data-raw|--data-binary)\s+(?:'([^']*)'|"([^"]*)")/);
  if (dataMatch) {
    body = (dataMatch[1] || dataMatch[2] || '').trim();
  }

  // 5. Generate friendly server name from URL
  let name = '';
  if (url) {
    try {
      const parsed = new URL(url);
      const host = parsed.hostname;
      const port = parsed.port ? `:${parsed.port}` : '';
      const path = parsed.pathname !== '/' ? parsed.pathname : '';
      name = `MCP (${host}${port}${path})`;
    } catch {
      name = 'Импортированный MCP';
    }
  }

  return {
    url,
    method,
    headers,
    bearerToken,
    body,
    name,
  };
}

/**
 * Universal Smart Importer:
 * Automatically detects whether clipboard text is a cURL command,
 * a JSON server export, Claude config, or a raw URL, and normalizes it.
 */
export function smartImportFromText(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    return { ok: false, error: 'Текст в буфере обмена пуст' };
  }

  const s = rawText.trim();

  // ── 1. Try parsing as JSON first ───────────────────────────────────────
  if (s.startsWith('{') || s.startsWith('[')) {
    try {
      const parsed = JSON.parse(s);

      // Full export format: { servers: [...], ... }
      if (parsed.servers && Array.isArray(parsed.servers) && parsed.servers.length > 0) {
        const first = parsed.servers[0];
        return {
          ok: true,
          type: 'JSON_FULL',
          serverCount: parsed.servers.length,
          allServers: parsed.servers,
          server: {
            name: first.name || 'Импортированный сервер',
            url: first.url || '',
            bearerToken: first.secrets?.bearer || first.token || '',
            headers: first.headers || {},
          },
        };
      }

      // Array format: [{ name, url, ... }]
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].url) {
        const first = parsed[0];
        return {
          ok: true,
          type: 'JSON_ARRAY',
          serverCount: parsed.length,
          allServers: parsed,
          server: {
            name: first.name || 'Импортированный сервер',
            url: first.url || '',
            bearerToken: first.secrets?.bearer || first.token || '',
            headers: first.headers || {},
          },
        };
      }

      // Claude desktop / generic config format: { "mcpServers": { "name": { "url": "..." } } }
      if (parsed.mcpServers && typeof parsed.mcpServers === 'object') {
        const entries = Object.entries(parsed.mcpServers);
        if (entries.length > 0) {
          const [sName, sVal] = entries[0];
          const sUrl = sVal.url || sVal.endpoint || (sVal.args ? sVal.args.find(a => typeof a === 'string' && a.startsWith('http')) : '');
          const sToken = sVal.headers?.Authorization?.replace(/^Bearer\s+/i, '') || sVal.token || '';
          return {
            ok: true,
            type: 'JSON_MCP_SERVERS',
            server: {
              name: sName,
              url: sUrl || '',
              bearerToken: sToken,
              headers: sVal.headers || {},
            },
          };
        }
      }

      // Single server object: { url: "...", ... }
      if (parsed.url) {
        return {
          ok: true,
          type: 'JSON_SINGLE',
          server: {
            name: parsed.name || parsed.title || 'Импортированный MCP',
            url: parsed.url,
            bearerToken: parsed.secrets?.bearer || parsed.bearerToken || parsed.token || '',
            headers: parsed.headers || {},
          },
        };
      }
    } catch {
      // not valid JSON, proceed to cURL detection
    }
  }

  // ── 2. Try parsing as cURL command ─────────────────────────────────────
  if (s.toLowerCase().startsWith('curl') || /\bcurl\s+/i.test(s)) {
    const curlResult = parseCurlCommand(s);
    if (curlResult && curlResult.url) {
      return {
        ok: true,
        type: 'CURL',
        server: {
          name: curlResult.name || 'cURL MCP сервер',
          url: curlResult.url,
          bearerToken: curlResult.bearerToken || '',
          headers: curlResult.headers || {},
        },
      };
    }
  }

  // ── 3. Raw URL fallback ────────────────────────────────────────────────
  if (/^https?:\/\/[^\s]+$/i.test(s)) {
    return {
      ok: true,
      type: 'URL',
      server: {
        name: 'MCP Сервер',
        url: s,
        bearerToken: '',
        headers: {},
      },
    };
  }

  return {
    ok: false,
    error: 'В буфере не найдены данные MCP (ожидается cURL команда, JSON конфиг или URL)',
  };
}
