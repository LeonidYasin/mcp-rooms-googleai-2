// ═══════════════════════════════════════════════════════════════════════════
// DeepSeek MCP Lite — Popup & SidePanel Script (v0.4.24)
// ═══════════════════════════════════════════════════════════════════════════

import { parseCurlCommand, generateCurlCommand, smartImportFromText } from './curl-utils.js';

const $ = (sel) => document.querySelector(sel);
const status = (text) => { const el = $('#status-bar'); if (el) el.textContent = text; };

function updateVersionBadge() {
  try {
    const manifest = chrome.runtime?.getManifest?.();
    const ver = manifest?.version || '0.4.24';
    const verEl = $('#app-version') || document.querySelector('span.ver');
    if (verEl) verEl.textContent = `v${ver}`;
  } catch {}
}
updateVersionBadge();
document.addEventListener('DOMContentLoaded', updateVersionBadge);

let config = null;

// ── View navigation (Settings vs Help) ────────────────────────────────────
$('#btn-toggle-help').addEventListener('click', () => {
  const isHelpVisible = $('#help-view').style.display === 'block';
  if (isHelpVisible) {
    showMainView();
  } else {
    showHelpView();
  }
});

$('#btn-back').addEventListener('click', showMainView);

function showHelpView() {
  $('#main-view').style.display = 'none';
  $('#help-view').style.display = 'block';
  $('#btn-toggle-help').textContent = '⚙️ К настройкам';
}

function showMainView() {
  $('#help-view').style.display = 'none';
  $('#main-view').style.display = 'block';
  $('#btn-toggle-help').textContent = '❓ Справка';
}

// ── Side Panel & Window Popout ───────────────────────────────────────────
$('#btn-open-sidepanel').addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.runtime.sendMessage({
      type: 'OPEN_SIDE_PANEL',
      windowId: tab?.windowId,
    }, (res) => {
      if (res?.mode === 'sidePanel') {
        window.close();
      } else {
        status('Открыта постоянная панель');
      }
    });
  } catch (err) {
    status(`Сбой открытия боковой панели: ${err.message}`);
  }
});

$('#btn-open-window').addEventListener('click', async () => {
  try {
    await chrome.windows.create({
      url: chrome.runtime.getURL('src/popup.html?mode=window'),
      type: 'popup',
      width: 540,
      height: 780,
    });
    window.close();
  } catch (err) {
    status(`Сбой открытия окна: ${err.message}`);
  }
});

if (window.location.search.includes('mode=window')) {
  document.body.style.maxWidth = '100%';
  $('#btn-open-window').style.display = 'none';
}

// ── FAQ accordion expand/collapse ────────────────────────────────────────
document.querySelectorAll('.faq-q').forEach(q => {
  q.addEventListener('click', () => {
    const item = q.parentElement;
    const answer = item.querySelector('.faq-a');
    const arrow = q.querySelector('span');
    const isClosed = answer.style.display === 'none';
    answer.style.display = isClosed ? 'block' : 'none';
    if (arrow) arrow.textContent = isClosed ? '▴' : '▾';
  });
});

// ── Form Draft Persistence (Auto-Save on Input) ──────────────────────────
function saveFormDraft() {
  const draft = {
    name: $('#new-name')?.value || '',
    url: $('#new-url')?.value || '',
    token: $('#new-token')?.value || '',
    headers: $('#new-headers')?.value || '',
    curlInput: $('#curl-paste-input')?.value || '',
  };
  chrome.storage.local.set({ dsmcp_form_draft: draft });
}

function restoreFormDraft() {
  chrome.storage.local.get('dsmcp_form_draft', (data) => {
    const d = data.dsmcp_form_draft;
    if (!d) return;
    const hasData = d.name || d.url || d.token || d.headers || d.curlInput;
    if (!hasData) return;

    if (d.name && $('#new-name')) $('#new-name').value = d.name;
    if (d.url && $('#new-url')) $('#new-url').value = d.url;
    if (d.token && $('#new-token')) $('#new-token').value = d.token;
    if (d.headers && $('#new-headers')) $('#new-headers').value = d.headers;
    if (d.curlInput && $('#curl-paste-input')) $('#curl-paste-input').value = d.curlInput;

    const addBox = $('#add-server-details');
    if (addBox) addBox.open = true;

    const notice = $('#draft-notice');
    if (notice) notice.style.display = 'flex';
  });
}

$('#btn-discard-draft')?.addEventListener('click', () => {
  clearNewServerForm();
  chrome.storage.local.remove('dsmcp_form_draft');
  const notice = $('#draft-notice');
  if (notice) notice.style.display = 'none';
  status('Черновик очищен');
});

['#new-name', '#new-url', '#new-token', '#new-headers', '#curl-paste-input'].forEach(sel => {
  const el = $(sel);
  if (el) el.addEventListener('input', saveFormDraft);
});

// ── Toggle Add Server Box ────────────────────────────────────────────────
$('#btn-toggle-add-box')?.addEventListener('click', () => {
  const box = $('#add-server-details');
  if (box) box.open = !box.open;
});

// ── Universal Smart Clipboard Paste (cURL / JSON / URL) ─────────────────
async function handleSmartPaste(rawText = null) {
  let text = rawText;
  if (!text) {
    try {
      text = await navigator.clipboard.readText();
    } catch {
      status('⚠ Не удалось прочитать буфер. Вставьте текст сочетанием Ctrl+V.');
      return;
    }
  }

  if (!text || !text.trim()) {
    status('⚠ Буфер обмена пуст');
    return;
  }

  const result = smartImportFromText(text);
  if (!result.ok) {
    showPasteBanner(`✗ ${result.error}`, false);
    status(`✗ ${result.error}`);
    return;
  }

  const s = result.server;
  const addBox = $('#add-server-details');
  if (addBox) addBox.open = true;

  if (s.url && $('#new-url')) $('#new-url').value = s.url;
  if (s.name && $('#new-name')) $('#new-name').value = s.name;
  if (s.bearerToken && $('#new-token')) $('#new-token').value = s.bearerToken;
  if (s.headers && Object.keys(s.headers).length > 0 && $('#new-headers')) {
    $('#new-headers').value = JSON.stringify(s.headers, null, 2);
  }

  saveFormDraft();

  let msg = `✓ Распознано (${result.type}): ${s.name || s.url}`;
  if (result.serverCount && result.serverCount > 1) {
    msg += ` (из ${result.serverCount} серверов взят первый)`;
  }
  showPasteBanner(msg, true);
  status(msg);
}

function showPasteBanner(msg, isSuccess = true) {
  const b = $('#paste-status-banner');
  if (!b) return;
  b.style.display = 'block';
  b.style.background = isSuccess ? '#064e3b' : '#450a0a';
  b.style.borderColor = isSuccess ? '#10b981' : '#ef4444';
  b.style.color = isSuccess ? '#6ee7b7' : '#fca5a5';
  b.textContent = msg;
  setTimeout(() => { b.style.display = 'none'; }, 4000);
}

$('#btn-paste-clipboard')?.addEventListener('click', () => handleSmartPaste());

document.addEventListener('paste', (e) => {
  const activeTag = document.activeElement?.tagName;
  if (activeTag === 'INPUT' || activeTag === 'TEXTAREA') return;
  const pastedText = e.clipboardData?.getData('text');
  if (pastedText) {
    handleSmartPaste(pastedText);
  }
});

// ── cURL Quick Import ────────────────────────────────────────────────────
$('#btn-apply-curl')?.addEventListener('click', () => {
  const rawCurl = $('#curl-paste-input')?.value.trim();
  if (!rawCurl) {
    status('⚠ Вставьте cURL команду в поле ввода');
    return;
  }

  const parsed = parseCurlCommand(rawCurl);
  if (!parsed || !parsed.url) {
    const el = $('#curl-parse-status');
    if (el) {
      el.style.color = '#ef4444';
      el.textContent = '✗ Не удалось распознать URL в cURL';
    }
    status('⚠ Ошибка: в команде cURL не найден корректный URL');
    return;
  }

  const addBox = $('#add-server-details');
  if (addBox) addBox.open = true;

  if ($('#new-url')) $('#new-url').value = parsed.url;
  if (parsed.name && $('#new-name') && !$('#new-name').value.trim()) {
    $('#new-name').value = parsed.name;
  }
  if (parsed.bearerToken && $('#new-token')) {
    $('#new-token').value = parsed.bearerToken;
  }
  if (parsed.headers && Object.keys(parsed.headers).length > 0 && $('#new-headers')) {
    $('#new-headers').value = JSON.stringify(parsed.headers, null, 2);
  }

  saveFormDraft();
  const el = $('#curl-parse-status');
  if (el) {
    el.style.color = '#34d399';
    el.textContent = '✓ Распознано и вставлено в форму!';
  }
  status(`✓ Извлечен URL: ${parsed.url}`);
});

// ── Load configuration & diagnostics ─────────────────────────────────────
chrome.runtime.sendMessage({ type: 'GET_CONFIG' }, (response) => {
  config = response || {};
  renderConfig();
  restoreFormDraft();
  loadDiagnostics();
  loadInterceptionAudit();
});

// ── Objective Control Live Traffic Inspector ─────────────────────────────
let lastInterceptionAudit = null;

function loadInterceptionAudit() {
  chrome.runtime.sendMessage({ type: 'GET_LAST_INTERCEPTION' }, (res) => {
    if (res?.audit) {
      renderInterceptionAudit(res.audit, res.totalCount);
    }
  });
}

function renderInterceptionAudit(audit, totalCount = 0) {
  if (!audit) return;
  lastInterceptionAudit = audit;

  const badge = $('#popup-audit-badge');
  const sum = $('#popup-audit-summary');
  const uBox = $('#popup-audit-user-text');
  const iBox = $('#popup-audit-injected-text');

  const isContinuation = audit.isContinuation || (audit.failReason && audit.failReason.includes('Продолжение'));

  if (audit.injected) {
    if (badge) {
      badge.className = 'audit-status-badge ok';
      badge.style = '';
      badge.textContent = `✓ ВНЕДРЕНО (${audit.toolCount} инстр.)`;
    }
    if (sum) {
      sum.innerHTML = `<strong>[${escHtml(audit.time)}]</strong> Внедрено <strong>${audit.toolCount} инстр.</strong> в <code>${escHtml(audit.url.split('?')[0])}</code>.<br><span style="color:#64748b">Всего сообщений: ${totalCount} (нажмите для деталей)</span>`;
    }
  } else if (isContinuation) {
    if (badge) {
      badge.className = 'audit-status-badge';
      badge.style.background = '#1e3a5f';
      badge.style.color = '#93c5fd';
      badge.style.border = '1px solid #3b82f6';
      badge.textContent = '✓ ПРОДОЛЖЕНИЕ';
    }
    if (sum) {
      sum.innerHTML = `<strong>[${escHtml(audit.time)}]</strong> Ответ инструмента передан в чат.<br><span style="color:#64748b">URL: ${escHtml(audit.url.split('?')[0])} (нажмите для деталей)</span>`;
    }
  } else {
    if (badge) {
      badge.className = 'audit-status-badge err';
      badge.style = '';
      badge.textContent = '✗ НЕ ВНЕДРЕНО';
    }
    if (sum) {
      sum.innerHTML = `<strong>[${escHtml(audit.time)}]</strong> Запрос перехвачен, инструменты не добавлены: <span style="color:#f87171">${escHtml(audit.failReason || 'Неизвестная причина')}</span>.<br><span style="color:#64748b">URL: ${escHtml(audit.url.split('?')[0])} (нажмите для деталей)</span>`;
    }
  }

  if (uBox) uBox.textContent = audit.userText || '(пусто)';
  if (iBox) iBox.textContent = audit.injectedPatch || audit.failReason || '(нет добавленного блока)';
}

// Click on audit box to toggle details drawer cleanly
$('#popup-audit-section')?.addEventListener('click', (e) => {
  if (e.target.closest('#popup-audit-drawer')) return;
  const dr = $('#popup-audit-drawer');
  if (dr) {
    dr.style.display = dr.style.display === 'none' ? 'block' : 'none';
  }
});

// Listen for broadcast audit updates
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'INTERCEPTION_AUDIT_BROADCAST') {
    renderInterceptionAudit(msg.audit, msg.totalCount);
  }
});

function renderConfig() {
  if ($('#enabled')) $('#enabled').checked = config.enabled || false;

  chrome.storage?.local?.get('dsmcp_show_widget', (data) => {
    if ($('#show-floating-widget')) {
      $('#show-floating-widget').checked = data?.dsmcp_show_widget !== false;
    }
  });

  // Rate Limiting
  const rl = config.rateLimit || {};
  if ($('#rl-delay')) $('#rl-delay').value = rl.delayBetweenCallsMs ?? 2000;
  if ($('#rl-max-per-min')) $('#rl-max-per-min').value = rl.maxCallsPerMinute ?? 10;
  if ($('#rl-timeout')) $('#rl-timeout').value = rl.timeoutMs ?? 30000;
  if ($('#rl-max-turns')) $('#rl-max-turns').value = rl.maxConsecutiveTurns ?? 5;
  if ($('#rl-max-bytes')) $('#rl-max-bytes').value = rl.maxResultBytes ?? 65536;
  if ($('#rl-confirm')) $('#rl-confirm').checked = rl.requireConfirmation || false;
  if ($('#rl-dom-input')) $('#rl-dom-input').checked = rl.preferDomInput || false;

  // Rollover & Compaction
  const ro = config.rollover || {};
  if ($('#ro-enabled')) $('#ro-enabled').checked = ro.enabled || false;
  if ($('#ro-threshold')) $('#ro-threshold').value = ro.tokenThreshold ?? 45000;
  if ($('#ro-format')) $('#ro-format').value = ro.format || 'markdown';
  if ($('#ro-download')) $('#ro-download').checked = ro.autoDownload !== false;
  if ($('#ro-navigate')) $('#ro-navigate').checked = ro.autoNavigate !== false;

  renderServers();
}

// ═══════════════════════════════════════════════════════════════════════════
//  SERVER CARDS WITH INLINE EDIT & INLINE TEST DRAWERS (NO SCROLLING!)
// ═══════════════════════════════════════════════════════════════════════════

function renderServers() {
  const container = $('#server-list');
  if (!container) return;
  container.innerHTML = '';
  const servers = config.servers || [];

  if (servers.length === 0) {
    container.innerHTML = '<div style="color:#64748b;font-size:12px;padding:10px;background:#131b2e;border:1px dashed #334155;border-radius:6px;text-align:center">Серверы еще не добавлены.<br>Нажмите <strong>«Вставить из буфера»</strong> выше или добавьте вручную.</div>';
    return;
  }

  for (const server of servers) {
    const card = document.createElement('div');
    card.className = 'server-card';
    card.id = `server-card-${server.id}`;
    card.dataset.cardId = server.id;

    const tools = (config.cachedTools || []).filter(t => t.serverId === server.id);
    const toolChips = tools.map(t => `<span class="tool-chip">${escHtml(t.name)}</span>`).join('');
    const headersStr = server.headers && Object.keys(server.headers).length > 0
      ? JSON.stringify(server.headers, null, 2)
      : '';

    card.innerHTML = `
      <div class="server-header">
        <span class="server-name">${escHtml(server.name)}</span>
        <div class="server-btns">
          <button class="btn-edit" data-edit-inline="${server.id}" title="Редактировать параметры прямо здесь">✏️ Изм.</button>
          <button class="btn-test" data-test-inline="${server.id}" title="Проверить соединение прямо здесь">🔍 Тест</button>
          <button class="secondary" data-curl-inline="${server.id}" title="Скопировать команду cURL для терминала">📋 cURL</button>
          <button class="danger" data-del="${server.id}" title="Удалить">✕</button>
        </div>
      </div>
      <div style="font-size:11px;color:#94a3b8;margin:4px 0;font-family:ui-monospace,monospace;word-break:break-all">
        ${escHtml(server.url)}
      </div>
      <div class="toggle-row" style="padding:2px 0">
        <span style="font-size:11px">Активен для чата</span>
        <label class="toggle">
          <input type="checkbox" data-toggle="${server.id}" ${server.enabled ? 'checked' : ''}>
          <span class="slider"></span>
        </label>
      </div>
      ${tools.length > 0
        ? `<div class="tool-list">${tools.length} инстр.: ${toolChips}</div>`
        : '<div class="tool-list" style="color:#64748b">Инструменты не загружены — нажмите 🔍 Тест или 🔄 Обновить</div>'
      }

      <!-- ── 1. INLINE TEST RESULT DRAWER (Directly under this server) ── -->
      <div class="inline-drawer inline-test-drawer" id="test-drawer-${server.id}" style="display:none"></div>

      <!-- ── 2. INLINE EDIT DRAWER (Directly under this server) ── -->
      <div class="inline-drawer inline-edit-drawer" id="edit-drawer-${server.id}" style="display:none">
        <div style="font-weight:600;color:#38bdf8;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center">
          <span>✏️ Редактирование: ${escHtml(server.name)}</span>
          <button class="secondary" data-close-edit="${server.id}" style="font-size:10px;padding:2px 6px">✕ Закрыть</button>
        </div>
        <label>Имя сервера</label>
        <input type="text" id="inline-name-${server.id}" value="${escAttr(server.name)}">
        <label>URL (HTTPS или http://localhost:*)</label>
        <input type="text" id="inline-url-${server.id}" value="${escAttr(server.url)}">
        <label>Bearer Token (если требуется авторизация)</label>
        <input type="password" id="inline-token-${server.id}" value="${escAttr(server.secrets?.bearer || '')}">
        <label>Кастомные заголовки (JSON, опционально)</label>
        <textarea id="inline-headers-${server.id}">${escHtml(headersStr)}</textarea>
        <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
          <button class="btn-save-inline" data-save-inline="${server.id}" style="flex:1">💾 Сохранить</button>
          <button class="secondary" data-test-form-inline="${server.id}" title="Проверить эти измененные параметры">🔍 Проверить</button>
          <button class="secondary" data-close-edit="${server.id}">Отмена</button>
        </div>
        <div id="inline-edit-status-${server.id}" style="margin-top:6px;display:none"></div>
      </div>
    `;
    container.appendChild(card);
  }

  // ── INLINE EDIT TOGGLE ────────────────────────────────────────────────
  container.querySelectorAll('[data-edit-inline]').forEach(btn => {
    btn.addEventListener('click', () => {
      const serverId = btn.dataset.editInline;
      const editDrawer = container.querySelector(`#edit-drawer-${serverId}`);
      const testDrawer = container.querySelector(`#test-drawer-${serverId}`);
      if (!editDrawer) return;

      const isHidden = editDrawer.style.display === 'none';
      // Close other drawers on this card
      if (testDrawer) testDrawer.style.display = 'none';

      editDrawer.style.display = isHidden ? 'block' : 'none';
      if (isHidden) {
        btn.textContent = '▲ Скрыть';
        const card = container.querySelector(`#server-card-${serverId}`);
        if (card) card.classList.add('editing');
      } else {
        btn.textContent = '✏️ Изм.';
        const card = container.querySelector(`#server-card-${serverId}`);
        if (card) card.classList.remove('editing');
      }
    });
  });

  // Close Inline Edit
  container.querySelectorAll('[data-close-edit]').forEach(btn => {
    btn.addEventListener('click', () => {
      const serverId = btn.dataset.closeEdit;
      const editDrawer = container.querySelector(`#edit-drawer-${serverId}`);
      const editBtn = container.querySelector(`[data-edit-inline="${serverId}"]`);
      const card = container.querySelector(`#server-card-${serverId}`);
      if (editDrawer) editDrawer.style.display = 'none';
      if (editBtn) editBtn.textContent = '✏️ Изм.';
      if (card) card.classList.remove('editing');
    });
  });

  // Save Inline Edit
  container.querySelectorAll('[data-save-inline]').forEach(btn => {
    btn.addEventListener('click', () => {
      const serverId = btn.dataset.saveInline;
      const nameInput = container.querySelector(`#inline-name-${serverId}`);
      const urlInput = container.querySelector(`#inline-url-${serverId}`);
      const tokenInput = container.querySelector(`#inline-token-${serverId}`);
      const headersInput = container.querySelector(`#inline-headers-${serverId}`);
      const statusDiv = container.querySelector(`#inline-edit-status-${serverId}`);

      const name = nameInput?.value.trim();
      const url = urlInput?.value.trim();
      const token = tokenInput?.value.trim();
      const headersRaw = headersInput?.value.trim();

      if (!name || !url) {
        showInlineStatus(statusDiv, '⚠ Имя и URL сервера обязательны', false);
        return;
      }

      let headers = {};
      if (headersRaw) {
        try {
          headers = JSON.parse(headersRaw);
        } catch {
          showInlineStatus(statusDiv, '⚠ Поле заголовков должно быть корректным JSON объектом', false);
          return;
        }
      }

      const updatedData = {
        id: serverId,
        name,
        url,
        secrets: token ? { bearer: token } : {},
        headers,
      };

      btn.textContent = 'Сохранение...';
      chrome.runtime.sendMessage({ type: 'UPDATE_SERVER', server: updatedData }, (res) => {
        btn.textContent = '💾 Сохранить';
        if (res?.ok) {
          showInlineStatus(statusDiv, '✓ Параметры сохранены!', true);
          status(`✓ Сервер "${name}" обновлен`);
          setTimeout(() => {
            renderConfig();
          }, 800);
        } else {
          showInlineStatus(statusDiv, `✗ Ошибка: ${res?.error || 'не удалось сохранить'}`, false);
        }
      });
    });
  });

  // Test form values directly inside inline edit drawer
  container.querySelectorAll('[data-test-form-inline]').forEach(btn => {
    btn.addEventListener('click', () => {
      const serverId = btn.dataset.testFormInline;
      const name = container.querySelector(`#inline-name-${serverId}`)?.value.trim() || 'Тест';
      const url = container.querySelector(`#inline-url-${serverId}`)?.value.trim();
      const token = container.querySelector(`#inline-token-${serverId}`)?.value.trim();
      const headersRaw = container.querySelector(`#inline-headers-${serverId}`)?.value.trim();
      const statusDiv = container.querySelector(`#inline-edit-status-${serverId}`);

      if (!url) {
        showInlineStatus(statusDiv, '⚠ Введите URL для проверки', false);
        return;
      }

      let headers = {};
      if (headersRaw) {
        try { headers = JSON.parse(headersRaw); } catch {
          showInlineStatus(statusDiv, '⚠ Некорректный JSON в заголовках', false);
          return;
        }
      }

      showInlineStatus(statusDiv, `⏳ Проверка соединения с ${url}...`, null);
      chrome.runtime.sendMessage({
        type: 'TEST_MCP_SERVER',
        server: { id: serverId, name, url, secrets: token ? { bearer: token } : {}, headers },
      }, (res) => {
        if (res.ok) {
          showInlineStatus(statusDiv, `✓ HTTP 200: найдено ${res.toolCount} инстр. (${res.latencyMs}мс)`, true);
        } else {
          showInlineStatus(statusDiv, `✗ ${res.error}`, false);
        }
        loadDiagnostics();
      });
    });
  });

  // ── INLINE TEST BUTTON (Directly under server card) ─────────────────────
  container.querySelectorAll('[data-test-inline]').forEach(btn => {
    btn.addEventListener('click', () => {
      const serverId = btn.dataset.testInline;
      const server = config.servers.find(s => s.id === serverId);
      if (!server) return;

      const testDrawer = container.querySelector(`#test-drawer-${serverId}`);
      const editDrawer = container.querySelector(`#edit-drawer-${serverId}`);
      if (!testDrawer) return;

      // Close edit drawer if open
      if (editDrawer) editDrawer.style.display = 'none';

      testDrawer.style.display = 'block';
      testDrawer.innerHTML = `
        <div style="display:flex;align-items:center;gap:6px;color:#93c5fd;font-size:11px">
          <span style="display:inline-block;animation:ds-spin 1s infinite">🔄</span>
          <span>Тестирование соединения с <strong>${escHtml(server.url)}</strong>...</span>
        </div>
      `;

      chrome.runtime.sendMessage({ type: 'TEST_MCP_SERVER', server }, (res) => {
        renderInlineTestResult(testDrawer, server, res);
        loadDiagnostics();
      });
    });
  });

  // ── COPY cURL BUTTON (Inline feedback) ──────────────────────────────────
  container.querySelectorAll('[data-curl-inline]').forEach(btn => {
    btn.addEventListener('click', () => {
      const serverId = btn.dataset.curlInline;
      const server = config.servers.find(s => s.id === serverId);
      if (!server) return;

      chrome.runtime.sendMessage({ type: 'GET_SERVER_CURL', server }, (res) => {
        if (res?.ok && res.curl) {
          navigator.clipboard.writeText(res.curl).then(() => {
            const oldText = btn.textContent;
            btn.textContent = '✓ Скопирован!';
            btn.style.color = '#34d399';
            setTimeout(() => {
              btn.textContent = oldText;
              btn.style.color = '';
            }, 2000);
            status(`✓ cURL команда для "${server.name}" скопирована в буфер!`);
          });
        }
      });
    });
  });

  // Delete Server Button
  container.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', () => {
      const serverId = btn.dataset.del;
      config.servers = config.servers.filter(s => s.id !== serverId);
      config.cachedTools = (config.cachedTools || []).filter(t => t.serverId !== serverId);
      saveAndRender();
      status('Сервер удален');
    });
  });

  // Toggle active for chat
  container.querySelectorAll('[data-toggle]').forEach(input => {
    input.addEventListener('change', () => {
      const server = config.servers.find(s => s.id === input.dataset.toggle);
      if (server) {
        server.enabled = input.checked;
        saveConfig();
      }
    });
  });
}

function showInlineStatus(el, msg, isSuccess) {
  if (!el) return;
  el.style.display = 'block';
  el.className = `inline-test-status ${isSuccess === true ? 'ok' : isSuccess === false ? 'err' : ''}`;
  el.textContent = msg;
}

function renderInlineTestResult(drawer, server, res) {
  const trace = res?.httpTrace || {};
  const isOk = Boolean(res?.ok);
  const curlCmd = res?.curl || trace?.curl || '';

  drawer.innerHTML = `
    <div class="inline-test-status ${isOk ? 'ok' : 'err'}">
      <span>${isOk ? `✓ HTTP 200: найдено ${res.toolCount} инстр. (${res.latencyMs}мс)` : `✗ Сбой: ${escHtml(res.error)}`}</span>
      <button class="secondary btn-close-inline-test" data-close-test="${server.id}" style="font-size:10px;padding:1px 6px">✕ Скрыть</button>
    </div>

    ${isOk && res.tools?.length > 0 ? `
      <div style="font-size:11px;color:#93c5fd;margin:4px 0">
        <strong>Доступные инструменты:</strong> ${res.tools.map(t => escHtml(t.name)).join(', ')}
      </div>
    ` : ''}

    <div style="font-size:10px;color:#94a3b8;margin-top:4px">
      <strong>Запрос:</strong> <code>POST ${escHtml(trace.url || server.url)}</code>
      ${trace.responseStatus ? ` | <strong>Ответ:</strong> <span style="color:${isOk ? '#34d399' : '#f87171'}">HTTP ${trace.responseStatus} ${escHtml(trace.responseStatusText || '')}</span>` : ''}
    </div>

    ${trace.responseBody ? `
      <div style="font-size:10px;color:#64748b;margin-top:4px">Тело ответа сервера (Raw Response):</div>
      <pre class="inline-trace-pre" style="color:${isOk ? '#38bdf8' : '#f87171'};max-height:80px;overflow-y:auto">${escHtml(trace.responseBody)}</pre>
    ` : ''}

    ${curlCmd ? `
      <details style="margin-top:6px" ${!isOk ? 'open' : ''}>
        <summary style="cursor:pointer;font-size:10px;color:#a78bfa;font-weight:600">💻 Точная команда cURL для терминала</summary>
        <pre class="inline-trace-pre" style="color:#a78bfa">${escHtml(curlCmd)}</pre>
        <button class="secondary btn-copy-inline-curl" data-copy-curl="${escAttr(curlCmd)}" style="font-size:10px;padding:2px 8px;margin-top:2px">📋 Скопировать cURL</button>
      </details>
    ` : ''}
  `;

  drawer.querySelector('[data-close-test]')?.addEventListener('click', () => {
    drawer.style.display = 'none';
  });

  drawer.querySelector('[data-copy-curl]')?.addEventListener('click', (e) => {
    const cmd = e.target.dataset.copyCurl;
    if (cmd) {
      navigator.clipboard.writeText(cmd).then(() => {
        const old = e.target.textContent;
        e.target.textContent = '✓ Скопировано!';
        setTimeout(() => { e.target.textContent = old; }, 2000);
      });
    }
  });
}

// ── Add New Server Drawer ────────────────────────────────────────────────
$('#btn-add-server')?.addEventListener('click', () => {
  const name = $('#new-name')?.value.trim();
  const url = $('#new-url')?.value.trim();
  const token = $('#new-token')?.value.trim();
  const headersRaw = $('#new-headers')?.value.trim();

  if (!name || !url) {
    status('⚠ Имя и URL сервера обязательны');
    return;
  }

  const isHttps = url.startsWith('https://');
  const isLocalhost = url.startsWith('http://localhost') || url.startsWith('http://127.0.0.1');

  if (!isHttps && !isLocalhost) {
    status('⚠ URL должен начинаться с https:// или http://localhost (127.0.0.1)');
    return;
  }

  let headers = {};
  if (headersRaw) {
    try {
      headers = JSON.parse(headersRaw);
    } catch {
      status('⚠ Поле заголовков должно быть корректным JSON объектом');
      return;
    }
  }

  const server = {
    id: crypto.randomUUID(),
    name,
    url,
    enabled: true,
    secrets: token ? { bearer: token } : {},
    headers,
  };

  if (!config.servers) config.servers = [];
  config.servers.push(server);

  clearNewServerForm();
  chrome.storage.local.remove('dsmcp_form_draft');
  const notice = $('#draft-notice');
  if (notice) notice.style.display = 'none';

  saveAndRender();
  status(`✓ Добавлен сервер "${server.name}"`);
});

$('#btn-test-form-server')?.addEventListener('click', () => {
  const name = $('#new-name')?.value.trim() || 'Новый сервер';
  const url = $('#new-url')?.value.trim();
  const token = $('#new-token')?.value.trim();
  const headersRaw = $('#new-headers')?.value.trim();

  if (!url) {
    status('⚠ Введите URL для проверки');
    return;
  }

  let headers = {};
  if (headersRaw) {
    try { headers = JSON.parse(headersRaw); } catch {
      status('⚠ Некорректный JSON в заголовках');
      return;
    }
  }

  status(`Проверка соединения с ${url}...`);
  chrome.runtime.sendMessage({
    type: 'TEST_MCP_SERVER',
    server: { id: 'temp-test', name, url, secrets: token ? { bearer: token } : {}, headers },
  }, (res) => {
    if (res.ok) {
      status(`✓ Сервер ответил за ${res.latencyMs}мс, найдено ${res.toolCount} инстр.`);
    } else {
      status(`✗ Ошибка: ${res.error}`);
    }
    loadDiagnostics();
  });
});

function clearNewServerForm() {
  if ($('#new-name')) $('#new-name').value = '';
  if ($('#new-url')) $('#new-url').value = '';
  if ($('#new-token')) $('#new-token').value = '';
  if ($('#new-headers')) $('#new-headers').value = '';
  const box = $('#add-server-details');
  if (box) box.open = false;
}

// ── Save Configuration ───────────────────────────────────────────────────
function readUiConfig() {
  config.enabled = $('#enabled')?.checked || false;
  config.rateLimit = {
    delayBetweenCallsMs: parseInt($('#rl-delay')?.value, 10) || 2000,
    maxCallsPerMinute: parseInt($('#rl-max-per-min')?.value, 10) || 10,
    maxConcurrent: 1,
    timeoutMs: parseInt($('#rl-timeout')?.value, 10) || 30000,
    maxConsecutiveTurns: parseInt($('#rl-max-turns')?.value, 10) || 5,
    maxResultBytes: parseInt($('#rl-max-bytes')?.value, 10) || 65536,
    requireConfirmation: $('#rl-confirm')?.checked || false,
    preferDomInput: $('#rl-dom-input')?.checked || false,
  };
  config.rollover = {
    enabled: $('#ro-enabled')?.checked || false,
    tokenThreshold: parseInt($('#ro-threshold')?.value, 10) || 45000,
    format: $('#ro-format')?.value || 'markdown',
    autoDownload: $('#ro-download')?.checked !== false,
    autoNavigate: $('#ro-navigate')?.checked !== false,
  };
}

function saveConfig() {
  readUiConfig();
  chrome.runtime.sendMessage({ type: 'SAVE_CONFIG', config }, () => {
    status('✓ Настройки сохранены и применены');
  });
}

function saveAndRender() {
  saveConfig();
  renderServers();
}

$('#btn-save')?.addEventListener('click', saveConfig);
$('#enabled')?.addEventListener('change', saveConfig);

$('#show-floating-widget')?.addEventListener('change', (e) => {
  const show = e.target.checked;
  chrome.storage?.local?.set({ dsmcp_show_widget: show });
  chrome.runtime.sendMessage({ type: 'TOGGLE_FLOATING_WIDGET', show });
  status(show ? '✓ Плавающий виджет включен' : '✓ Плавающий виджет скрыт с экрана чата');
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'WIDGET_VISIBILITY_CHANGED') {
    if ($('#show-floating-widget')) {
      $('#show-floating-widget').checked = msg.show;
    }
  }
});
$('#rl-confirm')?.addEventListener('change', saveConfig);
$('#rl-dom-input')?.addEventListener('change', saveConfig);
$('#ro-enabled')?.addEventListener('change', saveConfig);
$('#ro-format')?.addEventListener('change', saveConfig);
$('#ro-download')?.addEventListener('change', saveConfig);
$('#ro-navigate')?.addEventListener('change', saveConfig);

['#rl-delay', '#rl-max-per-min', '#rl-timeout', '#rl-max-turns', '#rl-max-bytes', '#ro-threshold'].forEach(sel => {
  const el = $(sel);
  if (el) el.addEventListener('change', saveConfig);
});

// ── Refresh Tools from All Active Servers ────────────────────────────────
$('#btn-refresh')?.addEventListener('click', () => {
  status('Опрос MCP серверов...');
  chrome.runtime.sendMessage({ type: 'REFRESH_TOOLS' }, (res) => {
    if (res.ok) {
      config.cachedTools = res.tools;
      renderServers();
      status(`✓ Загружено ${res.tools.length} инстр.`);
    } else {
      status(`✗ Сбой опроса: ${res.error}`);
    }
    loadDiagnostics();
  });
});

// ── Global Diagnostics Viewer ────────────────────────────────────────────
let currentDiagnostics = [];

function loadDiagnostics() {
  chrome.runtime.sendMessage({ type: 'GET_DIAGNOSTICS' }, (res) => {
    currentDiagnostics = res?.logs || [];
    renderDiagnostics();
  });
}

function renderDiagnostics() {
  const container = $('#popup-log');
  if (!container) return;
  container.innerHTML = '';

  if (currentDiagnostics.length === 0) {
    container.innerHTML = '<div style="color:#64748b;padding:8px">Лог пуст. Выполните проверку сервера или запрос.</div>';
    return;
  }

  for (let i = currentDiagnostics.length - 1; i >= 0; i--) {
    const entry = currentDiagnostics[i];
    const row = document.createElement('div');
    const timeStr = new Date(entry.time).toLocaleTimeString('ru', { hour12: false });
    const lvl = entry.level || 'info';
    row.className = `log-item ${lvl === 'success' ? 'ok' : lvl === 'error' ? 'err' : lvl}`;

    const trace = entry.httpTrace || null;
    const hasTrace = Boolean(trace);

    let badgeHtml = '';
    if (trace?.responseStatus) {
      const bClass = trace.responseStatus >= 200 && trace.responseStatus < 300 ? 'badge-200' : 'badge-err';
      badgeHtml = `<span class="log-status-badge ${bClass}">HTTP ${trace.responseStatus}</span>`;
    }

    row.innerHTML = `
      <div class="log-item-header" data-toggle-trace="${i}">
        <div>
          <span class="log-time">[${timeStr}]</span>
          <span class="log-msg">${escHtml(entry.message)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          ${badgeHtml}
          ${hasTrace ? '<span style="font-size:10px;color:#38bdf8;cursor:pointer">🔍 cURL / Детали ▾</span>' : ''}
        </div>
      </div>
      ${hasTrace ? renderTraceViewHtml(trace, i) : ''}
    `;

    container.appendChild(row);
  }

  container.querySelectorAll('[data-toggle-trace]').forEach(header => {
    header.addEventListener('click', () => {
      const traceIdx = header.dataset.toggleTrace;
      const traceEl = container.querySelector(`#trace-view-${traceIdx}`);
      if (traceEl) {
        const isHidden = traceEl.style.display !== 'block';
        traceEl.style.display = isHidden ? 'block' : 'none';
      }
    });
  });

  container.querySelectorAll('[data-copy-trace-curl]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const curlCmd = btn.dataset.copyTraceCurl;
      navigator.clipboard.writeText(curlCmd).then(() => {
        btn.textContent = '✓ Скопировано!';
        setTimeout(() => { btn.textContent = '📋 Скопировать cURL'; }, 2000);
      });
    });
  });
}

function renderTraceViewHtml(trace, idx) {
  const reqHeaders = trace.requestHeaders ? JSON.stringify(trace.requestHeaders, null, 2) : '{}';
  const reqBody = trace.requestBody ? (typeof trace.requestBody === 'string' ? trace.requestBody : JSON.stringify(trace.requestBody, null, 2)) : '(пусто)';
  const respHeaders = trace.responseHeaders ? JSON.stringify(trace.responseHeaders, null, 2) : '{}';
  const respBody = trace.responseBody ? trace.responseBody : '(пусто)';
  const curlCmd = trace.curl || '';

  return `
    <div class="trace-view" id="trace-view-${idx}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <span style="font-weight:600;color:#f1f5f9">📡 Точный протокол сетевого обмена:</span>
        ${curlCmd ? `<button class="secondary" style="font-size:10px;padding:2px 8px" data-copy-trace-curl="${escAttr(curlCmd)}">📋 Скопировать cURL</button>` : ''}
      </div>

      <div class="section-title">&gt;&gt;&gt; ИСХОДЯЩИЙ ЗАПРОС (REQUEST):</div>
      <div><strong>${escHtml(trace.method || 'POST')}</strong> ${escHtml(trace.url || '')}</div>
      <div style="color:#64748b;font-size:10px;margin-top:2px">Заголовки (Headers):</div>
      <pre>${escHtml(reqHeaders)}</pre>
      <div style="color:#64748b;font-size:10px;margin-top:2px">Тело (JSON-RPC Body):</div>
      <pre>${escHtml(reqBody)}</pre>

      <div class="section-title" style="margin-top:8px">&lt;&lt;&lt; ОТВЕТ СЕРВЕРА (RESPONSE):</div>
      <div>Статус: <strong>${escHtml(trace.responseStatus ? `HTTP ${trace.responseStatus} ${trace.responseStatusText || ''}` : trace.error || 'Нет соединения')}</strong></div>
      <div style="color:#64748b;font-size:10px;margin-top:2px">Заголовки ответа:</div>
      <pre>${escHtml(respHeaders)}</pre>
      <div style="color:#64748b;font-size:10px;margin-top:2px">Сырое тело ответа (Raw Body):</div>
      <pre style="color:${trace.responseStatus >= 400 ? '#f87171' : '#34d399'}">${escHtml(respBody)}</pre>

      ${curlCmd ? `
        <div class="section-title" style="margin-top:8px">💻 Команда cURL для проверки в терминале:</div>
        <pre style="color:#a78bfa">${escHtml(curlCmd)}</pre>
      ` : ''}
    </div>
  `;
}

$('#btn-clear-logs')?.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CLEAR_DIAGNOSTICS' }, () => {
    loadDiagnostics();
    status('Лог диагностических сообщений очищен');
  });
});

$('#btn-copy-logs')?.addEventListener('click', () => {
  const text = currentDiagnostics.map(e => {
    let str = `[${new Date(e.time).toISOString()}] [${e.level.toUpperCase()}] ${e.message}`;
    if (e.httpTrace) {
      str += `\n  URL: ${e.httpTrace.url}\n  Status: ${e.httpTrace.responseStatus || e.httpTrace.error}\n  cURL: ${e.httpTrace.curl || ''}`;
    }
    return str;
  }).join('\n\n');

  navigator.clipboard.writeText(text).then(() => {
    status('✓ Полные логи со всеми запросами скопированы в буфер');
  });
});

// ── Export Settings ──────────────────────────────────────────────────────
$('#btn-export')?.addEventListener('click', () => {
  readUiConfig();
  const exportData = {
    ...config,
    servers: (config.servers || []).map(s => ({
      ...s,
      secrets: s.secrets?.bearer ? { bearer: '***' } : {},
    })),
  };
  navigator.clipboard.writeText(JSON.stringify(exportData, null, 2))
    .then(() => status('✓ Конфигурация скопирована в буфер (токены скрыты)'))
    .catch(() => status('✗ Не удалось скопировать'));
});

// ── Helpers ──────────────────────────────────────────────────────────────
function escHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function escAttr(str) {
  return (str || '').replace(/"/g, '&quot;');
}
