// ═══════════════════════════════════════════════════════════════════════════
// DeepSeek MCP Lite — Session Packer, Compactor & Exporter
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Normalizes raw chat messages from DeepSeek's API
 */
export function extractMessages(rawHistory) {
  if (!rawHistory) return [];
  const bizData = rawHistory.data?.biz_data || rawHistory.biz_data || rawHistory.data || rawHistory;
  const messages = bizData?.chat_messages || (Array.isArray(bizData) ? bizData : []);
  return Array.isArray(messages) ? messages : [];
}

/**
 * Formats full chat history into a clean, human-readable Markdown file
 */
export function formatSessionToMarkdown(sessionId, rawHistory) {
  const messages = extractMessages(rawHistory);
  const now = new Date().toISOString();

  const lines = [
    `# Архив диалога DeepSeek: ${sessionId}`,
    `*Дата экспорта:* ${now}`,
    `*Всего сообщений:* ${messages.length}`,
    `*Создано плагином:* DeepSeek MCP Lite v0.3.0`,
    '',
    '---',
    '',
  ];

  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    const role = (msg.message_role || msg.role || '').toUpperCase();
    const isUser = role === 'USER';
    const time = msg.inserted_at || msg.created_at
      ? new Date(msg.inserted_at || msg.created_at).toLocaleString('ru')
      : `Шаг ${i + 1}`;

    const speaker = isUser ? '👤 Пользователь' : '🤖 DeepSeek';
    lines.push(`### ${speaker} (${time})`);
    lines.push('');

    // If there is thinking content
    if (msg.thinking_content) {
      lines.push('<details><summary>💭 Процесс рассуждения (Thinking)</summary>');
      lines.push('');
      lines.push(msg.thinking_content);
      lines.push('');
      lines.push('</details>');
      lines.push('');
    }

    const content = (msg.content || msg.prompt || '').trim();
    lines.push(content || '*(пустое сообщение)*');
    lines.push('');
    lines.push('---');
    lines.push('');
  }

  return lines.join('\n');
}

/**
 * Formats full chat history into indented JSON
 */
export function formatSessionToJson(sessionId, rawHistory) {
  const messages = extractMessages(rawHistory);
  return JSON.stringify({
    sessionId,
    exportedAt: new Date().toISOString(),
    plugin: 'DeepSeek MCP Lite v0.3.0',
    messageCount: messages.length,
    messages,
  }, null, 2);
}

/**
 * Algorithmic Context Compactor:
 * Synthesizes goal, key findings, tool results, and the latest pending state.
 */
export function compactSessionHistory(sessionId, rawHistory, backupFilename) {
  const messages = extractMessages(rawHistory);
  if (messages.length === 0) {
    return `[Контекст предыдущей сессии ${sessionId}: история пуста. Продолжаем работу.]`;
  }

  // 1. Identify primary user goal (first 1-2 user messages)
  const userMessages = messages.filter(m => (m.message_role || m.role || '').toUpperCase() === 'USER');
  const originalGoals = userMessages.slice(0, 2).map(m => (m.content || m.prompt || '').trim()).filter(Boolean);

  // 2. Identify executed tools and their findings
  const toolExecutions = [];
  const toolRegex = /\[Tool Result:\s*([^\]]+?)\]([\s\S]*?)\[\/Tool Result\]/g;

  for (const msg of messages) {
    const text = msg.content || msg.prompt || '';
    let match;
    while ((match = toolRegex.exec(text)) !== null) {
      const header = match[1].trim(); // e.g. "my_tool - SUCCESS"
      const toolName = header.replace(/\s+-\s+(SUCCESS|ERROR)$/i, '').trim();
      const status = /SUCCESS$/i.test(header) ? '✓' : /ERROR$/i.test(header) ? '✗' : '';
      const statusPrefix = status ? `[${status}] ` : '';
      const outputSnippet = match[2].trim().slice(0, 500); // Keep compact
      toolExecutions.push(`- ${statusPrefix}**${toolName}**: ${outputSnippet}`);
    }
  }

  // 3. Extract the last assistant response or latest user question
  const lastMsg = messages[messages.length - 1];
  const lastSpeaker = (lastMsg?.message_role || lastMsg?.role || '').toUpperCase() === 'USER' ? 'Пользователь' : 'DeepSeek';
  const lastContent = (lastMsg?.content || lastMsg?.prompt || '').trim();
  const lastSnippet = lastContent.length > 1200 ? lastContent.slice(-1200) + '...' : lastContent;

  // 4. Construct compact continuation payload
  const lines = [
    `[КОНТЕКСТ ПРЕДЫДУЩЕЙ СЕССИИ (АРХИВИРОВАНО)]`,
    `Предыдущая сессия (${sessionId}) подошла к лимиту токенов и была сохранена на диск в файл: ${backupFilename}`,
    '',
    `## 1. Исходная цель диалога:`,
    originalGoals.map(g => `> ${g}`).join('\n\n') || 'Не указана',
    '',
  ];

  if (toolExecutions.length > 0) {
    lines.push(`## 2. Результаты выполненных MCP-инструментов:`);
    lines.push(toolExecutions.slice(-8).join('\n'));
    lines.push('');
  }

  lines.push(`## 3. Последнее состояние перед переносом (${lastSpeaker}):`);
  lines.push(lastSnippet || 'Диалог ожидает продолжения');
  lines.push('');
  lines.push(`Инструкция модели: Это новая сессия, продолжающая задачу выше. Не повторяй уже выполненные шаги, продолжай с текущего состояния.`);
  lines.push(`[/КОНТЕКСТ ПРЕДЫДУЩЕЙ СЕССИИ (АРХИВИРОВАНО)]`);

  return lines.join('\n');
}

/**
 * Estimates token count based on string length and unicode characters
 */
export function estimateTokenCount(messages) {
  let totalChars = 0;
  for (const m of messages) {
    totalChars += (m.content || '').length;
    totalChars += (m.prompt || '').length;
    totalChars += (m.thinking_content || '').length;
  }
  // Rough estimate: 1 token ≈ 3.5 chars for mixed RU/EN/Code
  return Math.ceil(totalChars / 3.5);
}
